import { View, Text, TouchableOpacity, Linking } from 'react-native';
import React from 'react';

// Card that displays flight data
export default function FlightInfo({ flightData }) {
    // Build a usable booking URL
    const getBookingUrl = (airlineName, bookingUrl) => {
        if (bookingUrl) {
            const cleaned = bookingUrl.split(/\s|\(/)[0].trim();
            return cleaned;
        }

        const normalized = airlineName
            .toLowerCase()
            .replace(/\s+/g, '') // remove spaces
            .replace(/[^\w]/g, ''); // remove non-word characters

        const url = `https://www.${normalized}.com`;
        const cleaned = url.split(/\s|\(/)[0].trim();

        return cleaned;
    };

    // Open the URL in the system browser
    const handleOpenLink = () => {
        const url = getBookingUrl(flightData.airline, flightData.bookingUrl);

        Linking.openURL(url).catch((err) => {
            console.error('Failed to open URL:', err);
            alert('Could not open the booking page.');
        });
    };

    return (
        <View
        style={{
            marginTop: 20,
            borderColor: '#f2f2f2',
            borderWidth: 1,
            padding: 10,
            borderRadius: 15,
        }}
        >
            {/* Header */}
            <View
                style={{
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                }}
            >
                <Text
                style={{
                    fontFamily: 'outfit-bold',
                    fontSize: 20,
                }}
                >
                ✈️ Flights
                </Text>

                {/* Book button */}
                <TouchableOpacity
                    style={{
                        backgroundColor: '#000',
                        padding: 5,
                        width: 100,
                        borderRadius: 7,
                        marginTop: 7,
                    }}
                    onPress={handleOpenLink}
                >
                    <Text
                        style={{
                            textAlign: 'center',
                            color: '#fff',
                            fontFamily: 'outfit',
                        }}
                    >
                        Book Here
                    </Text>
                </TouchableOpacity>
            </View>

            {/* Airline name */}
            <Text
                style={{
                fontFamily: 'outfit',
                fontSize: 17,
                marginTop: 7,
                }}
            >
                Airline: {flightData.airline}
            </Text>

            {/* Price */}
            <Text
                style={{
                fontFamily: 'outfit',
                fontSize: 17,
                }}
            >
                Price: {`${String(flightData.flightPrice).replace(/€/g, '').trim()} €`}
            </Text>
        </View>
    );
}
