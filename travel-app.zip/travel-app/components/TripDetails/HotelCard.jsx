import { View, Text, Image, Pressable, Linking } from 'react-native';
import React, { useState, useEffect } from 'react';
import { GetPhotoRef } from '../../services/GooglePlaceApi';

// Card with hotel details
export default function HotelCard({ item }) {
    const [photoRef, setPhotoRef] = useState();

    useEffect(() => {
        GetGooglePhotoRef();
    }, []);

    // Attempt to fetch a photo for the hotel
    const GetGooglePhotoRef = async () => {
        const result = await GetPhotoRef(item?.hotelName);
        setPhotoRef(result?.results[0]?.photos[0]?.photo_reference);
    };

    // Build a URL for booking
    const handlePress = () => {
        // If your item already has a Booking URL, use it directly
        if (item.bookingUrl) {
            Linking.openURL(item.bookingUrl);
        } else {
            // Generate a Booking search URL based on hotel name
            const query = encodeURIComponent(item.hotelName);
            const bookingSearchUrl = `https://www.booking.com/searchresults.html?ss=${query}`;
            Linking.openURL(bookingSearchUrl);
        }
    };

    return (
        <Pressable onPress={handlePress}>
            <View style={{
                marginRight: 20,
                width: 180,
            }}>
                {/* Hotel photo */}
                <Image source={{
                        uri: 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=' 
                            + photoRef 
                            + '&key=' 
                            + process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY
                    }}
                    style={{
                        width: 180,
                        height: 120,
                        borderRadius: 15
                    }}
                />

                {/* Hotel name */}
                <View style={{ padding: 5 }}>
                    <Text style={{
                        fontFamily: 'outfit-medium',
                        fontSize: 17,
                    }}>{item.hotelName}</Text>
                </View>

                {/* Rating and price */}
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                    <Text style={{ fontFamily: 'outfit' }}>⭐ {item.rating}  </Text>
                    <Text style={{ fontFamily: 'outfit' }}>
                    💵 {String(item.pricePerNight).replace(/€/g, '').trim()} €/night
                    </Text>
                </View>
            </View>
        </Pressable>
    );
}
