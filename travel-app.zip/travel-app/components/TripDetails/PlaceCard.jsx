import { View, Text, Image, TouchableOpacity } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import React, { useState, useEffect } from 'react';
import { GetPhotoRef } from '../../services/GooglePlaceApi';
import { Linking } from 'react-native';

// Displays a planned place/activity inside the itinerary
export default function PlaceCard({ place }) {
  const [photoRef, setPhotoRef] = useState();

  useEffect(() => {
    GetGooglePhotoRef();
  }, []);

  // Fetch a Google Places photo reference for this place
  const GetGooglePhotoRef = async () => {
    const result = await GetPhotoRef(place?.activity ? place?.activity : place?.details);
    setPhotoRef(result?.results[0]?.photos?.[0]?.photo_reference);
  };

  // Build a Maps URL
  const openInMaps = () => {
    let url = '';
    const lat = place?.geoCoordinates?.latitude;
    const lng = place?.geoCoordinates?.longitude;

    if (typeof lat === 'number' && typeof lng === 'number') {
      url = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
    } else {
      const destination = encodeURIComponent(place?.activity || place?.details || '');
      url = `https://www.google.com/maps/search/?api=1&query=${destination}`;
    }

    Linking.openURL(url).catch((e) => {
      console.log('Failed to open maps:', e);
    });
  };

  return (
    <View
      style={{
        backgroundColor: '#e0e6ec95',
        padding: 12,
        borderRadius: 15,
        marginTop: 20,
        overflow: 'hidden',
      }}
    >
      {/* Place Photo */}
      {photoRef ? (
        <Image
          source={{
            uri:
              'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=' +
              photoRef +
              '&key=' +
              process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY,
          }}
          style={{
            width: '100%',
            height: 140,
            borderRadius: 12,
          }}
        />
      ) : (
        <View
          style={{
            width: '100%',
            height: 140,
            borderRadius: 12,
            backgroundColor: '#ccc',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name="image-outline" size={40} color="#888" />
          <Text
            style={{
              fontFamily: 'outfit',
              color: '#888',
              marginTop: 5,
            }}
          >
            No Image Available
          </Text>
        </View>
      )}

      <View style={{ marginTop: 10 }}>
        {/* Title */}
        <Text
          style={{
            fontFamily: 'outfit-bold',
            fontSize: 18,
            marginBottom: 4
          }}
        >
          {place?.activity}
        </Text>

        {/* Description */}
        <Text
          style={{
            fontFamily: 'outfit',
            fontSize: 14,
            color: '#7d7d7d',
            marginBottom: 10,
          }}
        >
          {place?.details}
        </Text>

        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <View style={{ flex: 1 }}>
            {/* Ticket price */}
            <Text
              style={{
                fontFamily: 'outfit',
                fontSize: 15,
                marginTop: 4,
              }}
            >
              🎟️ Ticket Price:{' '}
              <Text
                style={{
                  fontFamily: 'outfit-bold',
                }}
              >
                {place?.ticketPricing || ' -'}
              </Text>
            </Text>

            {/* Activity Duration */}
            <Text
              style={{
                fontFamily: 'outfit',
                fontSize: 17,
                marginTop: 5,
              }}
            >
              🕝 Duration:{' '}
              <Text
                style={{
                  fontFamily: 'outfit-bold',
                }}
              >
                {place?.duration || ' -'}
              </Text>
            </Text>
          </View>

          {/* Navigate button */}
          <TouchableOpacity
            style={{
              backgroundColor: '#000',
              paddingVertical: 8,
              paddingHorizontal: 12,
              borderRadius: 8,
              marginLeft: 12,
              alignSelf: 'flex-start',
            }}
            onPress={openInMaps}
          >
            <Ionicons name="navigate" size={18} color="white" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
