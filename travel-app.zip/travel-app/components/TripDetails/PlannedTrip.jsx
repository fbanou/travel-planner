import { View, Text } from 'react-native'
import React, { useEffect } from 'react';
import PlaceCard from './PlaceCard'

// Renders a trip planned itinerary
export default function PlannedTrip({details}) {
    useEffect(() => {
        console.log('trip deailes', details)
    }, []);

    return (
        <View style={{
            marginTop:20
        }}>
             {/* Section title */}
            <Text style={{
                fontSize:20,
                fontFamily:'outfit-bold'
            }}>🏕️ Plan Details</Text>

            {/* Each day section */}
            {Object.entries(details).sort().map(([day,details])=>(
                <View key={day}>
                    <Text style={{
                        fontFamily:'outfit-medium',
                        fontSize:20,
                        marginTop:20
                    }}>{details.day.replace(/([a-zA-Z])(\d)/, '$1 $2').toUpperCase()}</Text>
                    {/* Schedule list for the day */}
                    {details.schedule.map((place, index)=>(
                        <PlaceCard place={place} key={index} />
                    ))}
                </View>
            ))}
        </View>
    )
}