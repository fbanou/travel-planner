import React from 'react';
import {
    View, Text, TouchableOpacity, ScrollView,
    Image, Modal, Dimensions
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const screen = Dimensions.get('window');

// A modal that shows details for a selected place
export default function PlaceDetailsModal({
    place,
    visible,
    onClose,
    onFavoriteToggle,
    onRoutePress,
    isFavorite,
    travelMode,
    setTravelMode,
    apiKey,
}) {
    if (!place || !place.geometry?.location) return null;

    const hasPhotos = place?.photos?.length > 0;

    // Supported travel modes
    const travelModes = [
        { mode: 'driving', icon: 'car' },
        { mode: 'walking', icon: 'walk' },
        { mode: 'transit', icon: 'bus' },
        //{ mode: 'bicycling', icon: 'bicycle' },
    ];

    return (
        <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
            {/* Place card */}
            <View style={{ flex: 1, justifyContent: 'center' }}>
                <View style={{
                    backgroundColor: '#fff',
                    borderRadius: 20,
                    padding: 15,
                    marginHorizontal: 16,
                    maxHeight: '85%',
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.3,
                    shadowRadius: 10,
                    elevation: 10,
                }}>

                {/* Photos */}
                {hasPhotos ? (
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 10 }}>
                    {place?.photos?.map((photo, i) => (
                        <Image
                            key={i}
                            source={{
                                uri: `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${photo.photo_reference}&key=${apiKey}`,
                            }}
                            style={{ width: screen.width * 0.8, height: 200, marginRight: 10, borderRadius: 12 }}
                        />
                    ))}
                    </ScrollView>
                ) : (
                    <Image
                        source={{ uri: 'https://via.placeholder.com/300x200?text=No+Image' }}
                        style={{ width: '100%', height: 200, borderRadius: 12 }}
                    />
                )}

                {/* Title and Favorite */}
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
                    <Text style={{ fontSize: 20, fontWeight: '600', flex: 1 }}>{place.name}</Text>

                    <TouchableOpacity onPress={onFavoriteToggle}>
                        <Ionicons
                            name={isFavorite ? 'heart' : 'heart-outline'}
                            size={26}
                            color={isFavorite ? 'red' : '#555'}
                        />
                    </TouchableOpacity>
                </View>

                {/* Info */}
                <Text style={{ color: '#555', marginTop: 4 }}>{place.vicinity}</Text>
                <Text style={{ color: '#888' }}>⭐ {place.rating || 'N/A'} ({place.user_ratings_total || 0} reviews)</Text>

                {/* Travel mode selection */}
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around', marginVertical: 14 }}>
                    {travelModes.map(({ mode, icon }) => (
                        <TouchableOpacity
                            key={mode}
                            onPress={() => setTravelMode(mode)}
                            style={{
                            paddingVertical: 8,
                            paddingHorizontal: 16,
                            borderRadius: 30,
                            backgroundColor: travelMode === mode ? '#000' : '#eee',
                            flexDirection: 'row',
                            alignItems: 'center',
                            marginVertical: 4,
                            }}
                        >
                            <Ionicons
                                name={icon}
                                size={18}
                                color={travelMode === mode ? '#fff' : '#333'}
                                style={{ marginRight: 6 }}
                            />
                            <Text style={{ color: travelMode === mode ? '#fff' : '#333' }}>
                            {mode.charAt(0).toUpperCase() + mode.slice(1)}
                            </Text>
                        </TouchableOpacity>
                    ))}
                </View>

                {/* Show route */}
                <TouchableOpacity
                    style={{
                    backgroundColor: '#307bcaff',
                    borderRadius: 14,
                    paddingVertical: 10,
                    paddingHorizontal: 30,
                    alignItems: 'center',
                    alignSelf: 'center',
                    marginBottom: 12,
                    }}
                    onPress={onRoutePress}
                >
                    <Text style={{ color: '#fff', fontSize: 16 }}>➤  Show route</Text>
                </TouchableOpacity>

                {/* Close button */}
                <TouchableOpacity
                    onPress={onClose}
                    style={{
                    backgroundColor: '#000',
                    borderRadius: 14,
                    paddingVertical: 10,
                    paddingHorizontal: 30,
                    alignItems: 'center',
                    alignSelf: 'center',
                    }}
                >
                    <Text style={{ color: '#fff', fontSize: 16 }}>Close</Text>
                </TouchableOpacity>
                </View>
            </View>
        </Modal>
    );
}
