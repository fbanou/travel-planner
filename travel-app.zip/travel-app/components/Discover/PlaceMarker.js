import React from 'react';
import { Marker } from 'react-native-maps';

// Emoji for the marker title
const getMarkerEmoji = (type) => {
    switch (type) {
        case 'restaurant': return '🍽️';
        case 'cafe': return '☕';
        case 'museum': return '🖼️';
        case 'park': return '🌳';
        case 'lodging': return '🛌';
        default: return '📍';
    }
};

// Renders a place as a map marker
export default function PlaceMarker({ place, onPress }) {
    const coords = {
        latitude: place.geometry?.location.lat,
        longitude: place.geometry?.location.lng,
    };

    return (
        <Marker
            coordinate={coords}
            // Title shows an emoji and place name
            title={`${getMarkerEmoji(place.types?.[0])} ${place?.name}`}
            onPress={() => onPress(place)}
        />
    );
}
