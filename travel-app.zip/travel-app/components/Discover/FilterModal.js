import React from 'react';
import {
    View,
    Text,
    Modal,
    TouchableOpacity,
    ScrollView,
    StyleSheet,
    Pressable 
} from 'react-native';
import Slider from '@react-native-community/slider';

// Bottom sheet style modal for filtering nearby place results
export default function FilterModal({
    visible,
    types,
    selectedTypes,
    onToggleType,
    minRating,
    onSetMinRating,
    radius,
    setRadius,
    priceLevel,
    setPriceLevel,
    openNow,
    setOpenNow,
    onApply,
    onClear,
    onClose
}) {
    return (
        <Modal visible={visible} animationType="slide" transparent>
            {/* Tap outside to close */}
            <Pressable  style={styles.overlay} onPress={onClose}>
                <Pressable  style={styles.container} onPress={(e) => e.stopPropagation()}>
                    <Text style={styles.title}>Filters</Text>

                    {/* Types */}
                    <Text style={styles.subtitle}>Types</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.row}>
                        {types.map((t) => (
                        <TouchableOpacity
                            key={t.value}
                            onPress={() => onToggleType(t.value)}
                            style={[
                            styles.chip,
                            selectedTypes.includes(t.value) && styles.chipSelected,
                            ]}
                        >
                            <Text style={{ color: selectedTypes.includes(t.value) ? '#fff' : '#000' }}>
                                {t.label}
                            </Text>
                        </TouchableOpacity>
                        ))}
                    </ScrollView>

                    {/* Rating */}
                    <Text style={styles.subtitle}>Rating</Text>
                    <View style={styles.row}>
                        {[0, 3, 4, 4.5].map((r) => (
                        <TouchableOpacity
                            key={r}
                            onPress={() => onSetMinRating(r)}
                            style={[
                            styles.chip,
                            minRating === r && styles.chipSelected,
                            ]}
                        >
                            <Text style={{ color: minRating === r ? '#fff' : '#000' }}>
                                {r === 0 ? 'All' : `≥ ${r}`}
                            </Text>
                        </TouchableOpacity>
                        ))}
                    </View>

                    {/* Radius */}
                    <Text style={styles.subtitle}>Radius: {radius} m</Text>
                    <Slider
                        minimumValue={100}
                        maximumValue={5000}
                        step={100}
                        value={Number(radius)}
                        onValueChange={(val) => setRadius(String(val))}
                        minimumTrackTintColor="#000"
                        maximumTrackTintColor="#ccc"
                        style={{ marginBottom: 5 }}
                    />

                    {/* Price */}
                    <Text>Price</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
                        {[null, 0, 1, 2, 3, 4].map((p) => (
                            <TouchableOpacity
                                key={p ?? 'all'}
                                onPress={() => setPriceLevel(p)}
                                style={{
                                    backgroundColor: priceLevel === p ? '#000' : '#eee',
                                    padding: 8,
                                    borderRadius: 20,
                                    marginRight: 10,
                                }}
                            >
                                <Text style={{ color: priceLevel === p ? '#fff' : '#000' }}>
                                    {p === null ? 'All' : '€'.repeat(p + 1)}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </ScrollView>

                    {/* Open now */}
                    <TouchableOpacity
                        onPress={() => setOpenNow(!openNow)}
                        style={[styles.toggle, openNow && styles.toggleActive]}
                    >
                        <Text style={{ color: openNow ? '#fff' : '#000' }}>Open now</Text>
                    </TouchableOpacity>

                    {/* Reset and Apply Buttons */}
                    <View style={styles.buttonRow}>
                        <TouchableOpacity onPress={onClear} style={styles.secondaryButton}>
                            <Text style={styles.secondaryText}>Reset Filters</Text>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={onApply} style={styles.primaryButton}>
                            <Text style={styles.primaryText}>Apply</Text>
                        </TouchableOpacity>
                    </View>

                </Pressable >
            </Pressable >
        </Modal>
    );
}

// Styles
const styles = StyleSheet.create({
    overlay: {
        flex: 1,
        justifyContent: 'flex-end',
        //backgroundColor: 'rgba(0,0,0,0.4)',
    },
    container: {
        backgroundColor: '#fff',
        padding: 20,
        borderTopLeftRadius: 22,
        borderTopRightRadius: 22,
        elevation: 20,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 15,
    },
    subtitle: {
        marginTop: 10,
        marginBottom: 5,
        fontWeight: '500',
    },
    chip: {
        backgroundColor: '#eee',
        paddingVertical: 8,
        paddingHorizontal: 15,
        borderRadius: 20,
        marginRight: 8,
    },
    chipSelected: {
        backgroundColor: '#000',
    },
    row: {
        flexDirection: 'row',
        marginBottom: 5,
    },
    toggle: {
        backgroundColor: '#eee',
        padding: 10,
        borderRadius: 20,
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10
    },
    toggleActive: {
        backgroundColor: '#000',
    },
    primaryButton: {
        flex: 1,
        backgroundColor: '#000',
        padding: 12,
        borderRadius: 12,
        alignItems: 'center',
        marginLeft: 5,
    },
    primaryText: {
        color: '#fff',
        fontWeight: '600',
    },
    secondaryButton: {
        flex: 1,
        backgroundColor: '#ccc',
        padding: 12,
        borderRadius: 12,
        alignItems: 'center',
        marginRight: 5,
    },
    secondaryText: {
        fontWeight: '600',
    },
    buttonRow: {
        flexDirection: 'row',
        marginTop: 10,
    },
    closeButton: {
        marginTop: 10,
        alignItems: 'center',
    },
});
