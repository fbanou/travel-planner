import React from 'react';
import {
  View,
  TextInput,
  TouchableOpacity,
  Text,
  FlatList,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';

//  SearchBar used in the Discover screen
export default function SearchBar({
  searchText,
  setSearchText,
  suggestions,
  onSearch,
  onSelectSuggestion,
}) {

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{
        position: 'absolute',
        top: 40,
        left: 15,
        right: 15,
        zIndex: 999,
      }}
    >
      {/* Search Bar */}
      <View
        style={{
          backgroundColor: '#fff',
          borderRadius: 20,
          flexDirection: 'row',
          paddingHorizontal: 14,
          paddingVertical: 10,
          alignItems: 'center',
          shadowColor: '#000',
          shadowOpacity: 0.15,
          shadowRadius: 6,
          shadowOffset: { width: 0, height: 2 },
          elevation: 6,
          marginTop: 10
        }}
      >
        <Text style={{ fontSize: 18, marginRight: 8 }}>🔍</Text>

        {/* Controlled text input */}
        <TextInput
          placeholder="Search location..."
          value={searchText}
          onChangeText={setSearchText}
          onSubmitEditing={onSearch}
          style={{
            flex: 1,
            fontSize: 16,
            paddingVertical: 6,
          }}
          returnKeyType="search"
        />
      </View>

      {/* Suggestions Dropdown */}
      {suggestions.length > 0 && (
        <FlatList
          data={suggestions}
          keyExtractor={(item) => item.place_id}
          keyboardShouldPersistTaps="handled"
          style={{
            marginTop: 5,
            backgroundColor: '#fff',
            borderRadius: 16,
            shadowColor: '#000',
            shadowOpacity: 0.1,
            shadowRadius: 4,
            shadowOffset: { width: 0, height: 1 },
            elevation: 5,
            maxHeight: 250,
          }}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => onSelectSuggestion(item)}
              style={{
                paddingVertical: 12,
                paddingHorizontal: 18,
                borderBottomWidth: 1,
                borderBottomColor: '#eee',
              }}
            >
              <Text style={{ fontSize: 16 }}>{item.description}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </KeyboardAvoidingView>
  );
}
