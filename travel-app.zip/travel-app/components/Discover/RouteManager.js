import React, { useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Modal,
    ScrollView,
} from 'react-native';

// Info box with distance/duration and modal with step-by-step directions
export default function RouteManager({
    mapRef,
    onCancel,
    travelInfo,
    userRegion,
}) {
    const [stepsModalVisible, setStepsModalVisible] = useState(false);

    const stripHtml = (html) =>
        html.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');

    const getStepIcon = (mode) => {
        switch (mode?.toUpperCase()) {
            case 'WALKING':
                return '🚶';
            case 'DRIVING':
                return '🚗';
            case 'TRANSIT':
                return '🚌';
            case 'BICYCLING':
                return '🚴‍♂️';
            default:
                return '➡️';
        }
    };

    return (
        <>
            {/* Route Info Box */}
            {travelInfo && (
                <View
                style={{
                    position: 'absolute',
                    top: 60,
                    alignSelf: 'center',
                    backgroundColor: '#fff',
                    borderRadius: 16,
                    paddingVertical: 10,
                    paddingHorizontal: 20,
                    shadowColor: '#000',
                    shadowOpacity: 0.2,
                    shadowRadius: 4,
                    elevation: 5,
                    alignItems: 'center',
                    zIndex: 10,
                }}
                >
                    {/* Distance */}
                    <Text style={{ fontWeight: '600', color: '#333', fontSize: 16 }}>
                        🛣 {travelInfo.distance} ・⏱ {travelInfo.duration}
                    </Text>

                    {/* Transit line */}
                    {travelInfo.transitLine && (
                        <Text style={{ marginTop: 4, color: '#444', fontSize: 14 }}>
                        🚌 {travelInfo.transitLine.vehicle}:{' '}
                            <Text style={{ fontWeight: 'bold' }}>{travelInfo.transitLine.name}</Text>
                        </Text>
                    )}

                    {/* Instructions button */}
                    {travelInfo?.steps?.length > 0 && (
                        <TouchableOpacity onPress={() => setStepsModalVisible(true)} style={{ marginTop: 6 }}>
                            <Text style={{ color: '#007bff', fontWeight: '600' }}>📋 Instructions</Text>
                        </TouchableOpacity>
                    )}

                    {/* Cancel button */}
                    <TouchableOpacity
                        onPress={() => {
                            onCancel();
                            setStepsModalVisible(false);
                            if (mapRef?.current && userRegion) {
                                mapRef.current.animateToRegion(userRegion, 500);
                            }
                        }}
                        style={{ marginTop: 6 }}
                    >
                        <Text style={{ color: '#000', fontWeight: '600' }}>✖️ Cancel</Text>
                    </TouchableOpacity>
                </View>
            )}

            {/* Step-by-step directions Modal */}
            <Modal visible={stepsModalVisible} animationType="slide">
                <View style={{ flex: 1, padding: 20, backgroundColor: '#f8f8f8' }}>
                    <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 15, marginTop: 50 }}>
                        📝 Route Instructions
                    </Text>

                    <ScrollView>
                        {travelInfo?.steps?.map((step, index) => (
                        <View
                            key={index}
                            style={{
                            backgroundColor: '#fff',
                            borderRadius: 12,
                            padding: 12,
                            marginBottom: 10,
                            shadowColor: '#000',
                            shadowOpacity: 0.1,
                            shadowRadius: 4,
                            elevation: 2,
                            marginTop: 6
                            }}
                        >
                            <Text style={{ fontWeight: '600', marginBottom: 6 }}>
                            {getStepIcon(step.travel_mode)} {index + 1}
                            </Text>
                            <Text style={{ color: '#555' }}>{stripHtml(step.html_instructions)}</Text>
                        </View>
                        ))}
                    </ScrollView>

                    {/* Close button */}
                    <TouchableOpacity
                        onPress={() => setStepsModalVisible(false)}
                        style={{
                            marginTop: 20,
                            alignItems: 'center',
                            padding: 12,
                            backgroundColor: '#000',
                            borderRadius: 14,
                        }}
                    >
                        <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600', width: 'auto', alignSelf: 'center' }}>Close</Text>
                    </TouchableOpacity>
                </View>
            </Modal>
        </>
    );
}
