import React from 'react';
import {
  View, Text, TouchableOpacity, ScrollView,
  Image, Modal, Dimensions, StyleSheet 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import haversine from 'haversine-distance';

const screen = Dimensions.get('window');

// Shows details for a selected place and lets the user add it to their day plan
export default function PlaceDetailsModal({
    place,
    visible,
    onClose,
    onAdd,
    apiKey,
    tripLocation,
}) {
    if (!place || !place.geometry?.location) return null;

    const hasPhotos = place?.photos?.length > 0;

    // Distance from trip center to place
    const getDistance = () => {
      if (!tripLocation) return null;

      const from = { lat: tripLocation.latitude, lon: tripLocation.longitude };
      const to = { lat: place.geometry.location.lat, lon: place.geometry.location.lng };
      const meters = haversine(from, to);

      return `${Math.round(meters)} m away`;
    };

    return (
      <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
        <View style={styles.modalBackground}>
          <View style={styles.modalContainer}>

              {/* Photos */}
              {hasPhotos ? (
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 10 }}>
                    {place?.photos?.map((photo, i) => (
                        <Image
                            key={i}
                            source={{
                                uri: `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${photo?.photo_reference}&key=${apiKey}`,
                            }}
                            style={{ width: screen.width * 0.8, height: 200, marginRight: 10, borderRadius: 12 }}
                        />
                    ))}
                  </ScrollView>
              ) : (
                  <Image
                      source={{ uri: 'https://via.placeholder.com/300x200?text=No+Image' }}
                      style={{ width: '100%', height: 200, borderRadius: 12 }}
                  />
              )}

              {/* Place name */}
              <Text style={styles.modalTitle}>{place.name}</Text>

              {/* Ratings */}
              <Text style={styles.modalRating}>Rating: {place.rating ?? 'N/A'} ⭐ ({place.user_ratings_total || 0} reviews)</Text>
              <Text style={styles.modalAddress}>{place.vicinity}</Text>

              {/* Distance from trip location */}
              {getDistance() && (
                <Text style={{ color: '#888', marginBottom: 4 }}>
                  📍 {getDistance()}
                </Text>
              )}

              {/* Add to plan button */}
              <TouchableOpacity
                style={{
                  backgroundColor: '#000',
                  borderRadius: 14,
                  paddingVertical: 10,
                  paddingHorizontal: 30,
                  alignItems: 'center',
                  alignSelf: 'center',
                  marginBottom: 12,
                  marginTop: 10,
                  flexDirection: 'row', 
                  gap: 8,                
                }}
                onPress={onAdd}
              >
                <Ionicons name="add-outline" size={24} color="white" />
                <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>Add to Plan</Text>
              </TouchableOpacity>

              {/* Close button */}
              <TouchableOpacity
                  onPress={onClose}
                  style={{
                  backgroundColor: '#999',
                  borderRadius: 14,
                  paddingVertical: 10,
                  paddingHorizontal: 30,
                  alignItems: 'center',
                  alignSelf: 'center',
                  }}
              >
                  <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>Close</Text>
              </TouchableOpacity>
              </View>
          </View>
      </Modal>
    );
}

const styles = StyleSheet.create({
  modalBackground: {
    flex: 1,
    //backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 25,
    width: '90%',
    alignItems: 'center',
  },
  modalImage: {
    width: '100%',
    height: 180,
    borderRadius: 12,
    marginBottom: 18,
    resizeMode: 'cover',
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 6,
    textAlign: 'center',
    color: '#333',
    marginTop: 10
  },
  modalRating: {
    fontSize: 16,
    color: '#888',
    marginBottom: 4,
  },
  modalAddress: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 4,
  },
});
