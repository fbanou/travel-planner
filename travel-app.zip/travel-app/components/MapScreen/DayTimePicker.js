import React, { useState, useEffect } from 'react';
import {
  Modal, View, Text, TouchableOpacity, ScrollView,
  StyleSheet, Platform
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';

// Modal to pick day and time for adding activity
export default function DayTimePickerModal({
  visible,
  tripDays,
  selectedDay,
  selectedTime,
  setSelectedDay,
  setSelectedTime,
  onSave,
  onCancel
}) {
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [pickerDate, setPickerDate] = useState(new Date());

  // Reset time on modal close
  useEffect(() => {
    if (!visible) {
      setSelectedTime('');
      setPickerDate(new Date());
      setShowTimePicker(false);
    }
  }, [visible]);

  // Handle the time selection
  const handleTimeChange = (event, date) => {
    if (date) {
      setPickerDate(date);
      // Format HH:mm from Date
      const timeString = date.toTimeString().slice(0, 5);
      setSelectedTime(timeString);
    }

    if (Platform.OS !== 'ios') {
      setShowTimePicker(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onCancel}>
      <View style={styles.modalBackground}>
        <View style={styles.modalContainer}>
          {/* Day selector */}
          <Text style={styles.title}>Select Day</Text>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipRow}>
            {tripDays.map((day) => (
              <TouchableOpacity
                key={day}
                style={[styles.chip, selectedDay === day && styles.activeChip]}
                onPress={() => setSelectedDay(day)}
              >
                <Text style={[styles.chipText, selectedDay === day && styles.activeChipText]}>
                  {day}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Optional time selector */}
          <Text style={styles.title}>Optional Time</Text>

          <TouchableOpacity
            style={styles.timeButton}
            onPress={() => setShowTimePicker(true)}
          >
            <Text style={styles.timeText}>
              {selectedTime || 'No time selected'}
            </Text>
          </TouchableOpacity>

          {/* Time picker */}
          {showTimePicker && (
            <DateTimePicker
              value={pickerDate}
              mode="time"
              display={Platform.OS === 'ios' ? 'spinner' : 'default'}
              onChange={handleTimeChange}
              is24Hour={true}
              themeVariant="light" 
            />
          )}

          {/* Save button */}
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: '#000' }]}
            onPress={() => {
              onSave({ time: selectedTime });
            }}
          >
            <Text style={styles.actionText}>Save</Text>
          </TouchableOpacity>

          {/* Cancel button */}
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: '#888' }]}
            onPress={onCancel}
          >
            <Text style={styles.actionText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalBackground: {
    flex: 1,
    //backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    width: '90%',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 10,
    textAlign: 'center',
  },
  chipRow: {
    marginBottom: 10,
  },
  chip: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 10,
  },
  activeChip: {
    backgroundColor: '#000',
  },
  chipText: {
    fontWeight: '600',
    color: '#000',
  },
  activeChipText: {
    color: '#fff',
  },
  timeButton: {
    padding: 12,
    backgroundColor: '#eee',
    borderRadius: 20,
    marginBottom: 20,
    alignItems: 'center',
    alignSelf: 'center',
  },
  timeText: {
    fontSize: 16,
    fontWeight: '600',
  },
  actionBtn: {
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 30,
    alignItems: 'center',
    alignSelf: 'center',
    marginTop: 10,
  },
  actionText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});
