import React, { useMemo } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Calendar } from 'react-native-calendars';
import moment from 'moment';
import { useRouter } from 'expo-router';

// Calendar view of a trip
export default function TripCalendar({ tripData }) {
  const router = useRouter();

  // Build all marked dates
  const fullMarks = useMemo(() => {
    const markedDates = {};

    // Build a dot color map for days that have activities
    Object.entries(tripData.activities || {}).forEach(([dayStr, acts]) => {
      const date = moment(tripData.startDate)
        .add(Number(dayStr) - 1, 'days')
        .format('YYYY-MM-DD');

      if (acts.length > 0) {
        markedDates[date] = {
          marked: true,
          dotColor: acts.length > 3 ? '#ffeb3b' : '#90ee90',
        };
      }
    });

    // Highlights each day in the trip and emphasizes "today"
    const result = {};
    for (let i = 0; i < tripData.totalNoOfDays; i++) {
      const date = moment(tripData.startDate).add(i, 'days').format('YYYY-MM-DD');
      const isToday = date === moment().format('YYYY-MM-DD');
      const mark = markedDates[date];

      result[date] = {
        marked: !!mark,
        dotColor: mark?.dotColor,
        customStyles: {
          container: {
            backgroundColor: isToday ? '#307bcaff' : '#000',
            borderRadius: 12,
          },
          text: {
            color: '#fff',
            fontWeight: 'bold',
          },
        },
      };
    }

    return result;
  }, [tripData.activities, tripData.startDate, tripData.totalNoOfDays]);

  return (
    <ScrollView contentContainerStyle={{ paddingBottom: 150, marginTop: 30 }}>
      <View style={styles.calendarContainer}>
        <Calendar
          current={moment(tripData.startDate).format('YYYY-MM-DD')}
          markingType={'custom'}
          markedDates={fullMarks}
          minDate={moment(tripData.startDate).format('YYYY-MM-DD')}
          maxDate={moment(tripData.startDate)
            .add(tripData.totalNoOfDays - 1, 'days')
            .format('YYYY-MM-DD')}
          // Navigate to Day Details
          onDayPress={(day) => {
            const dayIndex = moment(day.dateString).diff(moment(tripData.startDate).startOf('day'), 'days');
            
            if (dayIndex >= 0 && dayIndex < tripData.totalNoOfDays) {
              router.push(`/activity/day-details?day=${dayIndex + 1}`);
            }
          }}
          theme={{
            todayTextColor: '#FF5722',
            arrowColor: '#000',
            monthTextColor: '#222',
            textDayFontWeight: '500',
            textMonthFontWeight: '700',
            textDayHeaderFontWeight: '600',
            textDayFontSize: 16,
            textMonthFontSize: 22,
            textDayHeaderFontSize: 13,
            backgroundColor: '#fff',
            calendarBackground: '#fff',
          }}
          style={styles.calendar}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  calendarContainer: {
    backgroundColor: '#fff',
    borderRadius: 15,
    margin: 10,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
  },
});

