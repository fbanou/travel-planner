import React from 'react';
import { Text, View, FlatList, TouchableOpacity, StyleSheet, Linking } from 'react-native';
import moment from 'moment';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

// Renders the days itinerary as timeline
export default function DayTimeline({ tripData, onDelete }) {
  const router = useRouter();

  // Build an array for the days of the trip
  const days = Array.from({ length: tripData?.totalNoOfDays || 0 }, (_, i) => i + 1);

  return (
    <FlatList
      data={days}
      keyExtractor={(day) => day.toString()}
      ListHeaderComponent={<Text style={styles.header}>Your Trip Plan</Text>}
      contentContainerStyle={{ paddingBottom: 150 }}
      renderItem={({ item: day }) => {
        const sorted = tripData.activities?.[day] || [];

        return (
          <View style={{ marginBottom: 30 }}>
            {/* Day header with date */}
            <Text style={styles.dayTitle}>
              Day {day} - {moment(tripData.startDate).add(day - 1, 'days').format('DD MMM YYYY')}
            </Text>

            {/* Empty state for a day with no activities */}
            {sorted.length === 0 && <Text style={{ fontStyle: 'italic', color: '#666' }}>No activities yet</Text>}

            {/* Activities list for the day */}
            {sorted.map((activity, index) => (
              <View key={index} style={styles.activityItem}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 10 }}>
                  {/* title, time, address, description */}
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontWeight: 'bold', fontSize: 16 }}>
                      {activity.time ? `${activity.time} - ` : ''}{activity.title}
                    </Text>

                    {activity.address ? <Text style={styles.address}>{activity.address}</Text> : null}

                    {activity.description ? <Text style={styles.description}>{activity.description}</Text> : null}
                  </View>

                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    {/* Open in maps */}
                    {activity.address && (
                      <TouchableOpacity
                        onPress={() => {
                          let url = `https://www.google.com/maps/search/?api=1&query=${activity?.title}, ${activity?.address}`;
                          Linking.openURL(url);
                        }}
                      >
                        <Ionicons name="navigate-outline" size={22} color="#000" />
                      </TouchableOpacity>
                    )}

                    {/* Edit activity */}
                    <TouchableOpacity onPress={() => router.push(`/activity/add-activity?day=${day}&editIndex=${index}`)}>
                      <Ionicons name="create-outline" size={22} />
                    </TouchableOpacity>

                    {/* Delete activity */}
                    <TouchableOpacity onPress={() => onDelete(day, index)}>
                      <Ionicons name="trash-outline" size={22} color="#F44336" />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}

             {/* Add new activity for this day */}
            <TouchableOpacity onPress={() => router.push(`/activity/add-activity?day=${day}`)} style={styles.addBtn}>
              <Text style={{ color: '#fff', fontWeight: 'bold' }}>+ Add Activity</Text>
            </TouchableOpacity>
          </View>
        );
      }}
    />
  );
}

const styles = StyleSheet.create({
  header: { fontSize: 30, fontWeight: 'bold', marginVertical: 20, marginTop: 80 },
  dayTitle: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
  activityItem: { paddingVertical: 8, borderBottomWidth: 1, borderColor: '#ddd', marginBottom: 10 },
  addBtn: { backgroundColor: '#000', padding: 10, borderRadius: 12, alignSelf: 'flex-start', marginTop: 10 },
  description: { fontSize: 14, color: '#555', marginTop: 2 },
  address: { fontSize: 14, color: '#999', marginTop: 2 },
});
