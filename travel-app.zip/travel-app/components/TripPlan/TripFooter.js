import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';

// Footer for Calendar, Timeline and Map views
export default function TripFooter({ showCalendar, onToggle, onSave, location }) {
  const router = useRouter();
  
  return (
    <View style={styles.footer}>
      {/* Toggle Calendar/Timeline */}
      <TouchableOpacity onPress={onToggle} style={[styles.footerBtn, styles.toggleBtn]}>
        <Text style={styles.footerBtnText}>{showCalendar ? 'Timeline' : 'Calendar'}</Text>
      </TouchableOpacity>

      {/* Open Map */}
      <TouchableOpacity
        onPress={() =>
          router.push({
            pathname: '/activity/map-view',
            params: {
              latitude: location?.lat,
              longitude: location?.lng,
            },
          })
        }
        style={[styles.footerBtn, styles.mapBtn]}
      >
        <Text style={styles.footerBtnText}>Map</Text>
      </TouchableOpacity>

      {/* Save Trip */}
      <TouchableOpacity onPress={onSave} style={[styles.footerBtn, styles.saveBtn]}>
        <Text style={styles.footerBtnText}>Save Trip</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 25,
    paddingVertical: 12,
    backgroundColor: '#f9f9f9',
    borderTopWidth: 1,
    borderColor: '#eee',
  },
  footerBtn: {
    flex: 1,
    marginHorizontal: 4,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  footerBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  toggleBtn: { backgroundColor: '#000' },
  mapBtn: { backgroundColor: '#000' },
  saveBtn: { backgroundColor: '#28a745' },
});
