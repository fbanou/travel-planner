import { View, Text, Image, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import moment from 'moment';
import UserTripCard from './UserTripCard';
import { useRouter } from 'expo-router';
import api from '../../services/api';
import { useState, useCallback } from 'react';
import StartNewTripCard from '../../components/MyTrips/StartNewTripCard';
import { Ionicons, AntDesign } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import AddUser from './AddUser';

// Displays a user's trips grouped by latest, upcoming, past trips and trips the user is a member of (upcoming & past)
export default function UserTripList({ trips, email }) {
  const [userTrips, setUserTrips] = useState(trips);
  const [loading, setLoading] = useState(false);

  const [showAddModal, setShowAddModal] = useState(false);
  const [adding, setAdding] = useState(false);
  const [memberTrips, setMemberTrips] = useState([]);

  const router = useRouter();
  const now = moment();

  // Re-fetch trips
  useFocusEffect(
    useCallback(() => {
      fetchTrips();
    }, [])
  );

  // Load both owned trips and trips the user is a member of
  const fetchTrips = async () => {
    try {
      setLoading(true);

      const [ownRes, memberRes] = await Promise.all([
        api.get(`/trips/${email}`),
        api.get(`/trips/member/${email}`),
      ]);

      setUserTrips(ownRes.data || []);
      setMemberTrips(memberRes.data || []);
    } catch (err) {
      //console.error('Failed to load trips:', err);
    } finally {
      setLoading(false);
    }
  };

  // Show loading while fetching
  /*if (loading) {
    return (
      <View style={{ marginTop: 50 }}>
        <ActivityIndicator size="large" />
      </View>
    );
  };*/

  // Delete a trip 
  const onDelete = async (tripId) => {
    try {
      console.log('Delete trip')
      await api.delete(`/trips/${tripId}`);
      fetchTrips();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (tripId) => {
    Alert.alert('Delete Trip', 'Are you sure you want to delete this trip?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => onDelete?.(tripId) },
    ]);
  };

  // Invite a user to trip
  const handleAddUser = async (email) => {
    try {
      setAdding(true);
      await api.patch('/trips/addUser', { tripId: latestTrip._id, email });

      Alert.alert('Success', 'User added to the trip');
      setShowAddModal(false);
    } catch (err) {
      const status = err?.response?.status;
      
      if (status === 404) {
        Alert.alert('User not found', 'We couldn’t find an account with that email');
      } else if (status === 409) {
        Alert.alert('Already a member', 'This user is already in the trip');
      } else  {
        Alert.alert('Error', err?.response?.data?.message || 'Failed to add user.');
      }
    } finally {
      setAdding(false);
    }
  };

  // Toggle favorite on a trip
  const handleToggleFavorite = async (tripId) => {
    try {
      await api.patch(`/trips/favorite/${tripId}`);
      console.log('Add to favorite trip')
      fetchTrips();
      
    } catch (err) {
      console.error(err);
    }
  };

  // Split owned trips into upcoming and past
  const upcomingTrips = userTrips
    .filter(trip => moment(trip.tripData?.startDate).isSameOrAfter(now, 'day'))
    .sort((a, b) => moment(a.tripData.startDate) - moment(b.tripData.startDate));

  const pastTrips = userTrips
    .filter(trip => moment(trip.tripData?.startDate).isBefore(now, 'day'))
    .sort((a, b) => moment(b.tripData.startDate) - moment(a.tripData.startDate));

  // Latest trip is the first upcoming trip
  const latestTrip = upcomingTrips[0];

  // Split and sort member trips
  const sharedUpcoming = memberTrips
  .filter(t => moment(t.tripData?.startDate).isSameOrAfter(now, 'day'))
  .sort((a,b) => moment(a.tripData.startDate) - moment(b.tripData.startDate));

  const sharedPast = memberTrips
  .filter(t => moment(t.tripData?.startDate).isBefore(now, 'day'))
  .sort((a,b) => moment(b.tripData.startDate) - moment(a.tripData.startDate));

  return (
    <View>
      {/* Highlighted latest trip */}
      {latestTrip && (
        <View style={{ marginTop: 20 }}>
          {/* Header */}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 20,
            }}
          >
            <Text style={{ fontFamily: 'outfit-bold', fontSize: 25 }}>
              Latest Trip
            </Text>

            <View style={{ flexDirection: 'row', gap: 15 }}>
              {/* Favorite Button */}
              <TouchableOpacity onPress={() => handleToggleFavorite(latestTrip._id)}>
                <Ionicons
                  name={latestTrip?.isFavorite ? 'heart' : 'heart-outline'}
                  size={24}
                  color={latestTrip?.isFavorite ? 'red' : 'black'}
                />
              </TouchableOpacity>

              {/* Delete Button */}
              <TouchableOpacity onPress={() => handleDelete(latestTrip._id)}>
                <Ionicons name="trash-outline" size={24} color="black" />
              </TouchableOpacity>

              {/* Add user button */}
              <TouchableOpacity onPress={() => setShowAddModal(true)} style={{paddingRight: 10}}>
                <AntDesign name="addusergroup" size={24} color="black" />
              </TouchableOpacity>
    
              {/* Invite modal */}
              <AddUser
                visible={showAddModal}
                onClose={() => setShowAddModal(false)}
                onSubmit={handleAddUser}
                loading={adding}
                title="Invite user to this trip"
                confirmText="Invite"
              />
            </View>
          </View>

          {/* Trip location image */}
          <Image
            source={
              latestTrip.tripData?.locationInfo?.photoRef
                ? {
                    uri:
                      'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=' +
                      latestTrip.tripData.locationInfo.photoRef +
                      '&key=' +
                      process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY,
                  }
                : (
                    <View
                      style={{
                        width: '100%',
                        height: 140,
                        borderRadius: 12,
                        backgroundColor: '#ccc',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Ionicons name="image-outline" size={40} color="#888" />
                      <Text
                        style={{
                          fontFamily: 'outfit',
                          color: '#888',
                          marginTop: 5,
                        }}
                      >
                        No Image Available
                      </Text>
                    </View>
                  )
            }
            style={{
              width: '100%',
              height: 300,
              borderRadius: 15,
              resizeMode: 'cover',
            }}
          />

          {/* Basic details */}
          <View style={{ marginTop: 10 }}>
            <Text style={{ fontFamily: 'outfit-medium', fontSize: 24 }}>
              {latestTrip.tripPlan?.tripDetails?.location ||
                latestTrip.tripData?.locationInfo?.name}
            </Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 5 }}>
              <Text style={{ fontFamily: 'outfit', fontSize: 17, color: '#7d7d7d' }}>
                {moment(latestTrip.tripData.startDate).format('DD ')}
                - {moment(latestTrip.tripData.endDate).format('DD MMM YYYY')}
              </Text>
              <Text style={{ fontFamily: 'outfit', fontSize: 17, color: '#7d7d7d' }}>
                🚍 {latestTrip.tripData?.traveler?.title}
              </Text>
            </View>

            {/* See your plan button */}
            <TouchableOpacity
              onPress={() => {
                const isCustom = latestTrip?.tripPlan;
                
                router.push({
                  pathname: isCustom ? '/trip-details' : '/trip-details/trip-custom',
                  params: { trip: JSON.stringify(latestTrip) },
                });
              }}
              style={{
                backgroundColor: '#000',
                padding: 15,
                borderRadius: 15,
                marginTop: 10,
              }}
            >
              <Text
                style={{
                  color: '#fff',
                  textAlign: 'center',
                  fontFamily: 'outfit-medium',
                  fontSize: 15,
                }}
              >
                See your plan
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Upcoming Trips (excluding latest) */}
      {upcomingTrips.length > 1 && (
        <View style={{ marginTop: 30 }}>
          <Text style={{ fontFamily: 'outfit-bold', fontSize: 20, marginBottom: 10 }}>
            Upcoming Trips
          </Text>
          {upcomingTrips.slice(1).map((trip, index) => (
            <UserTripCard
              trip={trip}
              key={`upcoming-${trip._id}`}
              fetchTrips={fetchTrips}
              role='owner'
            />
          ))}
        </View>
      )}

      {/* Past Trips */}
      {pastTrips.length > 0 && (
        <View style={{ marginTop: 30 }}>
          <Text style={{ fontFamily: 'outfit-bold', fontSize: 20, marginBottom: 10 }}>
            Past Trips
          </Text>
          {pastTrips.map((trip, index) => (
            <UserTripCard
              trip={trip}
              key={`past-${trip._id}`}
              fetchTrips={fetchTrips}
              role = 'owner'
            />
          ))}
        </View>
      )}

      {/* Trips you're a member of */}
      {(sharedUpcoming.length > 0 || sharedPast.length > 0) && (
        <View style={{ marginTop: 30 }}>
          <Text style={{ fontFamily: 'outfit-bold', fontSize: 20, marginBottom: 10 }}>
            Trips you’re a member of
          </Text>

          {sharedUpcoming.length > 0 && (
            <View style={{ marginBottom: 20 }}>
              <Text style={{ fontFamily: 'outfit-medium', fontSize: 18, marginBottom: 6 }}>Upcoming</Text>
              {sharedUpcoming.map(trip => (
                <UserTripCard
                  key={`shared-up-${trip._id}`}
                  trip={trip}
                  fetchTrips={fetchTrips}
                  role='member'     
                />
              ))}
            </View>
          )}

          {sharedPast.length > 0 && (
            <View>
              <Text style={{ fontFamily: 'outfit-medium', fontSize: 18, marginBottom: 6 }}>Past</Text>
              {sharedPast.map(trip => (
                <UserTripCard
                  key={`shared-p-${trip._id}`}
                  trip={trip}
                  fetchTrips={fetchTrips}
                  role='member'
                />
              ))}
            </View>
          )}
        </View>
      )}

      {/* If there are no trips at all, show starter card */}
      {userTrips.length === 0 && (
        <StartNewTripCard />
      )}
    </View>
  );
}
