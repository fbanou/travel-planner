import React, { useEffect, useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
} from 'react-native';

// Modal to add member in a trip
export default function AddUserModal({
  visible,
  onClose,
  onSubmit,
  loading = false,
  title = 'Invite user to this trip',
  confirmText = 'Invite',
  cancelText = 'Cancel',
  initialEmail = '',
}) {
  const [email, setEmail] = useState(initialEmail);
  const [touched, setTouched] = useState(false);

  // Reset input state each time the modal becomes visible
  useEffect(() => {
    if (visible) {
      setEmail(initialEmail || '');
      setTouched(false);
    }
  }, [visible, initialEmail]);

  // Email validation
  const validateEmail = (e) => /\S+@\S+\.\S+/.test(e);
  const hasError = touched && !validateEmail(email.trim());

  // Confirm handler
  const handleConfirm = async () => {
    setTouched(true);
    const value = email.trim();
    if (!validateEmail(value)) return;
    await onSubmit?.(value);
  };

  return (
    <Modal transparent visible={visible} animationType="fade" onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.select({ ios: 'padding', android: undefined })} style={{ flex: 1 }}>
        {/* Tap to close */}
        <Pressable style={styles.backdrop} onPress={onClose} />

        {/* Centered card */}
        <View style={styles.center}>
          <Pressable onPress={() => {}} style={({ pressed }) => [styles.card, pressed && { transform: [{ scale: 0.998 }] }]}>
            {/* Title */}
            <Text style={styles.title}>{title}</Text>

            {/* Email input */}
            <View style={[styles.inputWrap, hasError && styles.inputError]}>
              <TextInput
                placeholder="Enter user email"
                placeholderTextColor="#9aa0a6"
                value={email}
                onChangeText={(t) => {
                  setEmail(t);
                  if (!touched) setTouched(true);
                }}
                style={styles.input}
                keyboardType="email-address"
                autoCapitalize="none"
                editable={!loading}
                returnKeyType="send"
                onSubmitEditing={handleConfirm}
              />
            </View>

            {/* Inline error */}
            {hasError ? <Text style={styles.errorText}>Please enter a valid email.</Text> : <View style={{ height: 2 }} />}

            {/* Footer actions */}
            <View style={styles.footer}>
              {/* Close button */}
              <TouchableOpacity disabled={loading} onPress={onClose} style={styles.ghostBtn}>
                <Text style={styles.ghostText}>{cancelText}</Text>
              </TouchableOpacity>

              {/* Confirm button */}
              <TouchableOpacity
                disabled={loading}
                onPress={handleConfirm}
                style={[styles.primaryBtn, loading && { opacity: 0.7 }]}
              >
                {loading ? <ActivityIndicator /> : <Text style={styles.primaryText}>{confirmText}</Text>}
              </TouchableOpacity>
            </View>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.55)',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    width: '100%',
    maxWidth: 480,
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 10,
  },
  title: {
    fontSize: 20,
    fontFamily: 'outfit-medium',
    color: '#111',
    marginBottom: 12,
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    backgroundColor: '#FAFAFA',
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  inputError: {
    borderColor: '#ef4444',
  },
  atSign: {
    marginRight: 8,
    fontSize: 16,
    color: '#9aa0a6',
    fontWeight: '600',
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#111',
    fontFamily: 'outfit',
  },
  errorText: {
    color: '#ef4444',
    fontSize: 12,
    marginTop: 6,
    marginLeft: 4,
    fontFamily: 'outfit',
  },
  footer: {
    marginTop: 12,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    gap: 12,
  },
  ghostBtn: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
  },
  ghostText: {
    color: '#ef4444',
    fontFamily: 'outfit-medium',
    fontSize: 16,
  },
  primaryBtn: {
    paddingVertical: 12,
    paddingHorizontal: 18,
    backgroundColor: '#111',
    borderRadius: 12,
    minWidth: 108,
    alignItems: 'center',
  },
  primaryText: {
    color: '#fff',
    fontFamily: 'outfit-medium',
    fontSize: 16,
  },
});
