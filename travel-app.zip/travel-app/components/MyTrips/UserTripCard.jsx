import { View, Text, Image, TouchableOpacity, Alert } from 'react-native';
import React, { useState } from 'react';
import moment from 'moment';
import { useRouter } from 'expo-router';
import { Ionicons, AntDesign } from '@expo/vector-icons';
import api from '../../services/api';
import AddUser from './AddUser';

// Card for a trip in mytrips list
export default function UserTripCard({ trip, fetchTrips, role = 'owner' }) {
  const data = trip.tripData;
  const router = useRouter();
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [adding, setAdding] = useState(false);

  // Whether the current user can manage this trip
  const canManage = role === 'owner';

  // Delete trip
  const onDelete = async (tripId) => {
    try {
      console.log('Delete trip')
      await api.delete(`/trips/${tripId}`);
      
      fetchTrips();
    } catch (err) {
      console.error(err);
    }
  };

  // Confirm before deleting a trip
  const handleDelete = () => {
    Alert.alert('Delete Trip', 'Are you sure you want to delete this trip?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => onDelete?.(trip._id) },
    ]);
  };

  // Invite a user (by email) to this trip
  const handleAddUser = async (email) => {
    try {
      setAdding(true);
      await api.patch('/trips/addUser', { tripId: trip._id, email });

      Alert.alert('Success', 'User added to the trip.');
      setShowAddModal(false);
    } catch (err) {
      const status = err?.response?.status;

      if (status === 404) {
        Alert.alert('User not found', 'We couldn’t find an account with that email.');
      } else if (status === 409) {
        Alert.alert('Already a member', 'This user is already in the trip.');
      } else  {
        Alert.alert('Error', err?.response?.data?.message || 'Failed to add user.');
      }
      
    } finally {
      setAdding(false);
    }
  };

  // Toggle favorite on this trip
  const handleToggleFavorite = async (tripId) => {
    try {
      await api.patch(`/trips/favorite/${tripId}`);
      console.log('Add to favorites')
      fetchTrips();
      
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <View
      style={{
        marginTop: 20,
        display: 'flex',
        flexDirection: 'row',
        gap: 10,
        alignItems: 'center',
        backgroundColor: '#f5f5f5',
        borderRadius: 15,
        padding: 10,
      }}
    >
      {/* Destination image */}
      <Image
        source={{
          uri:
            'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=' +
            data?.locationInfo?.photoRef +
            '&key=' +
            process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY,
        }}
        style={{
          width: 100,
          height: 100,
          borderRadius: 15,
        }}
      />

      <View style={{ flex: 1 }}>
        {/* Destination name */}
        <Text
          style={{
            fontFamily: 'outfit-medium',
            fontSize: 18,
          }}
        >
          {trip?.tripPlan?.tripDetails?.location || data?.locationInfo?.name}
        </Text>

        {/* Dates */}
        <Text
          style={{
            fontFamily: 'outfit',
            fontSize: 14,
            color: '#7d7d7d',
          }}
        >
          {moment(data?.startDate).format('DD ')}
          - {moment(data?.endDate).format('DD MMM YYYY')}
        </Text>

        {/* Traveler label */}
        <Text
          style={{
            fontFamily: 'outfit',
            fontSize: 14,
            color: '#7d7d7d',
            marginBottom: 5,
          }}
        >
          Traveling: {data?.traveler?.title}
        </Text>

        {/* Buttons Row */}
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
          {/* See Your Plan */}
          <TouchableOpacity
            onPress={() => {
              const isCustom = trip?.tripPlan;
              router.push({
                pathname: isCustom ? '/trip-details' : '/trip-details/trip-custom',
                params: { trip: JSON.stringify(trip) },
              });
            }}
            style={{
              backgroundColor: '#000',
              paddingVertical: 6,
              paddingHorizontal: 12,
              borderRadius: 10,
            }}
          >
            <Text
              style={{
                color: '#fff',
                fontFamily: 'outfit-medium',
                fontSize: 14,
              }}
            >
              See your plan
            </Text>
          </TouchableOpacity>
          
          {canManage && (
            <>
              {/* Add to Favorites */}
              <TouchableOpacity onPress={()=>handleToggleFavorite(trip._id)}>
                <Ionicons
                  name={trip.isFavorite ? 'heart' : 'heart-outline'}
                  size={24}
                  color={trip.isFavorite ? 'red' : 'black'}
                />
              </TouchableOpacity>

              {/* Delete Trip */}
              <TouchableOpacity onPress={handleDelete}>
                <Ionicons name="trash-outline" size={24} color="black" />
              </TouchableOpacity>

              <TouchableOpacity onPress={() => setShowAddModal(true)} style={{paddingRight: 10}}>
                <AntDesign name="addusergroup" size={24} color="black" />
              </TouchableOpacity>

              {/* Add member in a trip */}
              <AddUser
                visible={showAddModal}
                onClose={() => setShowAddModal(false)}
                onSubmit={handleAddUser}
                loading={adding}
                title="Invite user to this trip"
                confirmText="Invite"
              />
            </>
          )}
        </View>
      </View>
    </View>
  );
}
