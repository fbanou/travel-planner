import { View, Text, TouchableOpacity } from 'react-native'
import React from 'react'
import Ionicons from '@expo/vector-icons/Ionicons';
import { useRouter } from 'expo-router';

// Card that appears when the user has no trips
export default function StartNewTripCard() {
  const router=useRouter();

  return (
    <View style={{
        padding:20,
        marginTop:50,
        display:'flex',
        alignItems:'center',
        gap:25
    }}>
      {/* Decorative icon */}
      <Ionicons name="location-sharp" size={30} color="black" />

      {/* Headline */}
      <Text style={{
        fontFamily:'outfit-medium',
        fontSize:25
      }}>No trips planned yet</Text>

      {/* Subtittle */}
      <Text style={{
        fontFamily:'outfit',
        fontSize:20,
        textAlign:'center',
        color:'#7d7d7d'
      }}>Looks like no trips planned yet. Get started now</Text>

      {/* Create trip button */}
      <TouchableOpacity 
      onPress={()=>router.push('/create-trip/search-place')}
      style={{
        padding:15,
        backgroundColor:'#000',
        borderRadius:15,
        paddingHorizontal:30
      }}>
        <Text style={{
            color:'#fff',
            fontFamily:'outfit-medium',
            fontSize:17
        }}>Start a new trip</Text>
      </TouchableOpacity>
    </View>
  )
}