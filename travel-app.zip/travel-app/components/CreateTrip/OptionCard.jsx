import { View, Text, StyleSheet } from 'react-native'
import React from 'react'

// Card used in selection lists (e.g., traveler type, budget)
export default function OptionCard({option, selectedOption}) {
    // Determine if this card is currently selected
    const selected = selectedOption?.id === option?.id;

    return (
        <View style={[styles.card, selected && styles.cardSelected]}>
            {/* title + description */}
            <View>
                <Text style={styles.title}>{option?.title}</Text>
                <Text style={styles.desc}>{option?.desc}</Text>
            </View>

            {/* icon */}
            <Text style={styles.icon}>{option?.icon}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    card: {
        padding: 25,
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: '#f2f2f2',
        borderRadius: 15,
    },
    cardSelected: {
        borderWidth: 3,
        borderColor: '#000',
    },
    title: {
        fontFamily: 'outfit-bold',
        fontSize: 20,
    },
    desc: {
        fontFamily: 'outfit',
        fontSize: 17,
        color: '#7d7d7d',
    },
    icon: {
        fontSize: 35,
    },
});