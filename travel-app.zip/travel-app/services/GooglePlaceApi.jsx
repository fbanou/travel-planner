import axios from "axios";

// Uses Google Places Text Search API to get details of a place by name
export const GetPhotoRef = async (placeName) => {
    const resp = await fetch(
        "https://maps.googleapis.com/maps/api/place/textsearch/json" +
        "?query=" +
        placeName +
        "&key=" +
        process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY
    );

    const result = await resp.json();
    console.log(result);
    return result;
};

// Fetches nearby places using Google Places Nearby Search API
export const fetchNearbyPlaces = async ({
    location,
    radius,
    types,
    minPrice,
    maxPrice,
    openNow,
    apiKey,
    }) => {
    // Run parallel requests for all requested types
    const requests = types.map((type) =>
        axios.get("https://maps.googleapis.com/maps/api/place/nearbysearch/json", {
            params: {
                location,
                radius,
                type,
                key: apiKey,
                opennow: openNow ? true : undefined,
                minprice: minPrice,
                maxprice: maxPrice,
            },
        })
    );

    // Wait for all requests to resolve
    const responses = await Promise.all(requests);

    // Flatten results across all type queries
    const all = responses.flatMap((res) => res.data.results || []);

    // Deduplicate by place_id
    const unique = Array.from(new Map(all.map((p) => [p.place_id, p])).values());

    // Collect pagination token
    const nextToken = responses.find((r) => r.data.next_page_token)?.data
        .next_page_token;

    return { places: unique, nextPageToken: nextToken };
};

// Fetches next page of results from Nearby Search API
export const fetchNextPage = async (token, apiKey) => {
    // Google requires small delay before token becomes valid
    await new Promise((res) => setTimeout(res, 2000));

    const res = await axios.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json', {
        params: {
        pagetoken: token,
        key: apiKey,
        },
    });

    return {
        places: res.data.results || [],
        nextPageToken: res.data.next_page_token || null,
    };
};

// Gets directions between origin and destination using Directions API
export const fetchRoute = async ({ origin, destination, mode, apiKey }) => {
    const res = await axios.get(
        "https://maps.googleapis.com/maps/api/directions/json",
        {
            params: { origin, destination, mode, key: apiKey },
        }
    );

    return res.data.routes[0];
};

// Converts an address into latitude/longitude using Geocoding API
export const geocodeAddress = async (address, apiKey) => {
    const res = await axios.get(
        "https://maps.googleapis.com/maps/api/geocode/json",
        {
            params: { address, key: apiKey },
        }
    );

    return res.data.results[0]?.geometry?.location || null;
};

// Fetches photos for a place
export const fetchPlacePhotos = async (placeId, apiKey) => {
    const res = await axios.get('https://maps.googleapis.com/maps/api/place/details/json', {
        params: {
        place_id: placeId,
        fields: 'photos',
        key: apiKey,
        },
    });

    return res.data.result.photos || [];
};

// Retrieves detailed information for a place (name, opening hours, phone, etc.)
export const fetchPlaceDetails = async (placeId, apiKey) => {
    try {
        const res = await axios.get(
        'https://maps.googleapis.com/maps/api/place/details/json',
        {
            params: {
                place_id: placeId,
                key: apiKey,
            },
        }
        );

        return res.data.result;
    } catch (err) {
        console.error('Place details error:', err);
        return null;
    }
};
