import { View, Text, ActivityIndicator, ScrollView, TouchableOpacity } from 'react-native';
import React, { useEffect, useState, useContext } from 'react';
import Ionicons from '@expo/vector-icons/Ionicons';
import StartNewTripCard from '../../components/MyTrips/StartNewTripCard';
import UserTripList from '../../components/MyTrips/UserTripList';
import api from '../../services/api';
import { AuthContext } from '../../context/AuthContext';
import { useRouter } from 'expo-router';

// Main screen to view and manage a user's trips
export default function MyTrip() {
  const { user } = useContext(AuthContext);
  const [userTrips, setUserTrips] = useState([]);
  const [loading, setLoading] = useState(false);
  const [memberTrips, setMemberTrips] = useState([]);
  const router = useRouter();

  // Fetch trips when user is available
  useEffect(() => {
    user && GetMyTrips();
  }, [user]);

  // Fetch user's own and member trips from API
  const GetMyTrips = async () => {
    try {
      setLoading(true);

      const [ownRes, memberRes] = await Promise.all([
        api.get(`/trips/${user.email}`),
        api.get(`/trips/member/${user.email}`),
      ]);

      setUserTrips(ownRes.data || []);
      setMemberTrips(memberRes.data || []);
    } catch (err) {
      console.error('Failed to load trips:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <ScrollView
        style={{
          padding: 25,
          paddingTop: 55,
          backgroundColor: '#fff',
        }}
        contentContainerStyle={{ paddingBottom: 60 }}
      >
        {/* Header row */}
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Text
            style={{
              fontFamily: 'outfit-bold',
              fontSize: 35,
            }}
          >
            My Trips
          </Text>

          {/* Show "Add New Trip" button only if trips exist */}
          {(memberTrips.length > 0 || userTrips.length > 0) && (
            <TouchableOpacity onPress={() => router.push('/create-trip/search-place')}>
              <Ionicons name="add-circle" size={50} color="black" />
            </TouchableOpacity>
          )}
        </View>

        {/* Loader */}
        {loading && (
          <ActivityIndicator size={'large'} color="#000" style={{ marginTop: 30 }} />
        )}

        {/* Conditional trip rendering */}
        {!loading && memberTrips.length === 0 && userTrips.length === 0 ? (
           // Show "Start New Trip" card if no trips exist
          <StartNewTripCard />
        ) : (
          // Show user's trips list
          <UserTripList trips={userTrips} email={user?.email} />
        )}
      </ScrollView>
    </View>
  );
}
