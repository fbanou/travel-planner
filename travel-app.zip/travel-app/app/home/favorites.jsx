import React, { useState, useContext, useCallback } from 'react';
import {
  View,
  Text,
  Linking,
  StyleSheet,
  Image,
  ActivityIndicator,
  TouchableOpacity,
  Alert,
  SectionList,
  Platform
} from 'react-native';
import { AuthContext } from '../../context/AuthContext';
import api from '../../services/api';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import moment from 'moment';
import { useFocusEffect } from '@react-navigation/native';

//  Shows all user favorites, divided into Favorite Places and Favorite Trips 
export default function FavoritesScreen() {
  const { user } = useContext(AuthContext);
  const [favoriteTrips, setFavoriteTrips] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const GOOGLE_API_KEY = process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY;

  // Refresh favorites
  useFocusEffect(
    useCallback(() => {
      fetchFavorites();
      fetchFavoriteTrips();
    }, [])
  );

  // Fetch trips marked as favorites
  const fetchFavoriteTrips = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/Trips/favorites/${user.email}`);
      setFavoriteTrips(res.data || []);
    } catch (err) {
      console.log('Error fetching trips:', err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch favorite places
  const fetchFavorites = async () => {
    setLoading(true);

    try {
      const res = await api.get(`/favorites/${user.email}`);
      setFavorites(res.data);
    } catch (err) {
      console.log('Error fetching favorites:', err);
      Alert.alert('Error', 'Could not fetch your favorites');
    } finally {
      setLoading(false);
    }
  };

  // Remove a place from favorites
  const handleRemove = async (placeId) => {
    try {
      await api.delete(`/favorites/${user.email}/${placeId}`);
      setFavorites((prev) => prev.filter((fav) => fav.placeId !== placeId));
    } catch (err) {
      console.log('Error removing favorite:', err);
      Alert.alert('Error', 'Could not remove the favorite');
    }
  };

  // Remove a trip from favorites
  const handleDelete = async (tripId) => {
    try {
      const res = await api.patch(`/trips/favorite/${tripId}`);
      setFavoriteTrips((prev) => prev.filter((fav) => fav._id !== tripId));
      console.log('trip id: ', res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // Open location in map
  const openInMaps = (address) => {
    const url = Platform.select({
      ios: `http://maps.apple.com/?daddr=${encodeURIComponent(address)}`,
      android: `http://maps.google.com/?daddr=${encodeURIComponent(address)}`
    });
    Linking.openURL(url);
  };

  // Render card for a favorite trip
  const renderTripItem = ({ item }) => (
    <View style={styles.card}>
      <Image
        source={{
          uri:
            'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=' +
            item?.tripData?.locationInfo?.photoRef +
            '&key=' +
            GOOGLE_API_KEY,
        }}
        style={styles.image}
      />
      <View style={styles.info}>
        <Text style={styles.name}>{item?.tripPlan?.tripDetails?.location || item?.tripData?.locationInfo?.name}</Text>
        <Text style={styles.address}>{moment(item?.tripData?.startDate).format('DD MMM YYYY')}</Text>
        <Text style={styles.rating}>Traveling: {item?.tripData?.traveler?.title}</Text>

        {/* Buttons */}
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
          <TouchableOpacity
            onPress={() => {
              const isCustom = item?.tripPlan;
              console.log(item)
              router.push({
                pathname: isCustom ? '/trip-details' : '/trip-details/trip-custom',
                params: { trip: JSON.stringify(item) },
              });
            }}
            style={styles.button}
          >
            <Text style={styles.buttonText}>See your plan</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.deleteButton}
            onPress={() =>
              Alert.alert(
                'Remove',
                'Are you sure you want to remove this favorite?',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Yes', onPress: () => handleDelete(item._id) },
                ]
              )
            }
          >
            <Ionicons name="trash-outline" size={20} color="black" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  // Render card for a favorite place
  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <Image
        source={{
          uri: item.photoReference
            ? `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${item.photoReference}&key=${GOOGLE_API_KEY}`
            : 'https://via.placeholder.com/300',
        }}
        style={styles.image}
      />
      <View style={styles.info}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.address}>{item.address}</Text>
        <Text style={styles.rating}>⭐ {item.rating || 'N/A'}</Text>
      </View>

      {/* Buttons */}
      <View style={styles.buttonContainer}>
        {/* Remove from favorites */}
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() =>
            Alert.alert(
              'Remove',
              'Are you sure you want to remove this favorite?',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Yes', onPress: () => handleRemove(item.placeId) },
              ]
            )
          }
        >
          <Ionicons name="trash-outline" size={20} color="black" />
        </TouchableOpacity>

        {/* Navigate in Maps */}
        <TouchableOpacity style={styles.button} onPress={() => openInMaps(item?.address)}>
          <Ionicons name="navigate" size={20} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, paddingTop: 55, backgroundColor: '#fff' }}>
      {/* Title */}
      <Text style={{ fontFamily: 'outfit-bold', fontSize: 35, paddingHorizontal: 25 }}>
        All The Favorites
      </Text>

      {/* Loader */}
      {loading ? (
        <ActivityIndicator size="large" color="#000" style={{ marginTop: 30 }} />
      ) : (
        <SectionList
          contentContainerStyle={{ padding: 15, paddingBottom: 60 }}
          sections={[
            {
              title: 'Favorite Places',
              data: favorites,
              renderItem: renderItem,
              keyExtractor: (item) => item.placeId,
            },
            {
              title: 'Favorite Trips',
              data: favoriteTrips,
              renderItem: renderTripItem,
              keyExtractor: (item) => item._id,
            },
          ]}
          renderSectionHeader={({ section: { title, data } }) => (
            <View style={{ marginTop: 20 }}>
              <Text style={styles.sectionTitle}>{title}</Text>
              {data.length === 0 && (
                <View style={{
                  padding:15,
                  marginTop:15,
                  display:'flex',
                  alignItems:'center',
                  gap:15
                }}>
                  <Ionicons name="heart" size={30} color="black" />
                  <Text style={styles.noFavoritesText}>
                    {title === 'Favorite Places' ? 'No favorite places added yet' : 'No favorite trips added yet'}
                  </Text>
                </View>
              )}
            </View>
          )}
          ListEmptyComponent={
            <Text style={styles.noFavoritesText}>No favorites added yet</Text>
          }
          stickySectionHeadersEnabled={false}
        />
      )}
    </View>
  );
}

// Styles for the screen
const styles = StyleSheet.create({
  image: {
    width: 100,
    height: 100,
    borderRadius: 12,
    resizeMode: 'cover',
  },
  card: {
    backgroundColor: '#fff',
    marginBottom: 15,
    borderRadius: 16,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  info: {
    flex: 1,
    marginLeft: 12,
  },
  name: {
    fontFamily: 'outfit-bold',
    fontSize: 16,
    color: '#111',
    marginBottom: 4,
  },
  address: {
    fontFamily: 'outfit',
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  rating: {
    fontFamily: 'outfit',
    fontSize: 14,
    color: '#888',
  },
  buttonContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    gap: 10,
    marginLeft: 10,
  },
  deleteButton: {
    backgroundColor: 'transparent',
    padding: 10,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionTitle: {
    fontFamily: 'outfit-bold',
    fontSize: 22,
    marginTop: 25,
    marginBottom: 10,
    paddingHorizontal: 10,
    color: '#222',
  },
  noFavoritesText: {
    fontFamily: 'outfit',
    fontSize: 16,
    color: '#888',
    textAlign: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 14,
    fontFamily: 'outfit-medium',
  },
  button: {
    backgroundColor: '#000',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 10,
    marginTop: 8,
    alignSelf: 'flex-start',
  },
});

