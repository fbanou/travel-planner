import { View, Text, TouchableOpacity, TextInput, Image, Alert, ScrollView, StyleSheet } from 'react-native';
import React, { useContext, useState } from 'react';
import { AuthContext } from '../../context/AuthContext';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';

// User profile screen to view and edit account info
export default function Profile() {
  const { user, logout, updateUser, deleteAccount } = useContext(AuthContext);
  const router = useRouter();

  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [editing, setEditing] = useState(false);

  // Save profile changes
  const handleSave = async () => {
    if (!name || !email) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    const success = await updateUser(name, email);
    if (success) {
      Alert.alert('Success', 'Profile updated');
      setEditing(false);
    } else {
      Alert.alert('Error', 'Failed to update profile');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>
      <ScrollView contentContainerStyle={{ padding: 25, paddingTop: 55, paddingBottom: 60 }}>
        {/* Title */}
        <Text style={styles.title}>Your profile</Text>

        {/* Profile image */}
        <View style={{ alignItems: 'center', marginBottom: 30 }}>
          <Image
            source={require('./../../assets/images/profile.png')}
            style={{ width: 200, height: 200 }}
            resizeMode="contain"
          />
        </View>

        {/* Info card */}
        <View style={styles.infoCard}>
          <Text style={styles.label}>Full Name:</Text>
          {editing ? (
            <TextInput
              value={name}
              onChangeText={setName}
              style={styles.input}
              placeholder="Enter full name"
            />
          ) : (
            <Text style={styles.text}>{user?.name || 'No Name'}</Text>
          )}

          <Text style={styles.label}>Email:</Text>
          {editing ? (
            <TextInput
              value={email}
              onChangeText={setEmail}
              style={styles.input}
              placeholder="Enter email"
              keyboardType="email-address"
              autoCapitalize="none"
            />
          ) : (
            <Text style={styles.text}>{user?.email || 'No Email'}</Text>
          )}
        </View>

        {/* Edit and Save buttons */}
        {editing ? (
          <TouchableOpacity onPress={handleSave} style={styles.saveButton}>
            <Text style={styles.saveButtonText}>Save Changes</Text>
            <Ionicons name="checkmark-sharp" size={24} color="white" style={{ marginLeft: 8 }} />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={() => setEditing(true)} style={styles.editButton}>
            <Text style={styles.saveButtonText}>Edit Profile</Text>
            <FontAwesome6 name="user-pen" size={20} color="white" style={{ marginLeft: 8 }} />
          </TouchableOpacity>
        )}

        {/* Re-arranged buttons when not editing */}
        {!editing && (
          <>
            {/* Delete Account Button */}
            <TouchableOpacity
              onPress={() =>
                Alert.alert(
                  'Confirm Delete',
                  'Are you sure you want to delete your account? This action cannot be undone.',
                  [
                    { text: 'Cancel', style: 'cancel' },
                    {
                      text: 'Delete',
                      style: 'destructive',
                      onPress: async () => {
                        const success = await deleteAccount();
                        if (success) {
                          Alert.alert('Success','Account deleted!');
                          router.replace('/auth/sign-in');
                        } else {
                          Alert.alert('Error', 'Failed to delete account');
                        }
                      },
                    },
                  ]
                )
              }
              style={styles.deleteButton}
            >
              <Text style={styles.deleteText}>Delete Account</Text>
              <FontAwesome6 name="user-slash" size={18} color="white" style={{ marginLeft: 8 }} />
            </TouchableOpacity>

            {/* Log Out Button */}
            <TouchableOpacity
              onPress={() => logout(() => router.replace('/auth/sign-in'))}
              style={styles.logoutButton}
            >
              <Text style={styles.logoutText}>Log Out</Text>
              <Ionicons name="log-out-outline" size={24} color="white" style={{ marginLeft: 8 }} />
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </View>
  );
}

// Styles for this screen
const styles = StyleSheet.create({
  title: {
    fontFamily: 'outfit-bold',
    fontSize: 32,
    textAlign: 'left',
    marginBottom: 15,
  },
  infoCard: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 20,
    paddingVertical: 30,
    paddingHorizontal: 25,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 15,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
    marginBottom: 30,
  },
  label: {
    fontSize: 20,
    color: '#555',
    marginBottom: 8,
    fontFamily: 'outfit-medium',
  },
  text: {
    fontSize: 25,
    fontWeight: '700',
    color: '#111',
    marginBottom: 25,
    fontFamily: 'outfit-bold',
  },
  input: {
    fontSize: 18,
    borderWidth: 1,
    borderColor: '#aaa',
    padding: 10,
    borderRadius: 10,
    marginBottom: 25,
    fontFamily: 'outfit',
  },
  editButton: {
    backgroundColor: '#000',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 30,
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: 'auto',
    alignSelf: 'center',
  },
  saveButton: {
    backgroundColor: '#000',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 30,
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: 'auto',
    alignSelf: 'center',
  },
  logoutButton: {
    backgroundColor: '#ff3b30',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 30,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: 'auto',
    alignSelf: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
    fontFamily: 'outfit-bold',
    textAlign: 'center',
  },
  logoutText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
    fontFamily: 'outfit-bold',
    textAlign: 'center',
  },
  deleteButton: {
    backgroundColor: '#000',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 30,
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: 'auto',
    alignSelf: 'center',
  },
  deleteText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
    fontFamily: 'outfit-bold',
    textAlign: 'center',
  },
});

