import React, { useEffect, useState, useRef, useContext } from 'react';
import { View, ActivityIndicator, Alert, Keyboard, TouchableOpacity, Text } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import * as Location from 'expo-location';
import { useNavigation } from 'expo-router';
import { FAB, Portal } from 'react-native-paper';
import { AuthContext } from '../../context/AuthContext';
import { placeTypes } from '../../constants/placeTypes';
import SearchBar from '../../components/Discover/SearchBar';
import FilterModal from '../../components/Discover/FilterModal';
import PlaceDetailsModal from '../../components/Discover/PlaceDetailsModal';
import PlaceMarker from '../../components/Discover/PlaceMarker';
import RouteManager from '../../components/Discover/RouteManager';
import api from '../../services/api';
import { decode as decodePolyline } from '@mapbox/polyline';
import {
  fetchNearbyPlaces,
  fetchRoute,
  fetchPlaceDetails,
  fetchNextPage
} from '../../services/GooglePlaceApi';

// Explore nearby places on a map
export default function Discover() {
  const { user } = useContext(AuthContext);
  const mapRef = useRef(null);
  const navigation = useNavigation();
  const GOOGLE_API_KEY = process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY;

  // Map & place state
  const [region, setRegion] = useState(null); // user's region on map
  const [rawPlaces, setRawPlaces] = useState([]); // unfiltered results
  const [places, setPlaces] = useState([]); // filtered results
  const [selectedPlace, setSelectedPlace] = useState(null);

  // Routing state
  const [travelInfo, setTravelInfo] = useState(null);
  const [travelMode, setTravelMode] = useState('driving');
  const [routeSegments, setRouteSegments] = useState([]);

  const [searchText, setSearchText] = useState('');
  const [fabOpen, setFabOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [favorite, setFavorite] = useState(false);
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [showSearchBar, setShowSearchBar] = useState(false);
  const [nextPageToken, setNextPageToken] = useState(null);
  const [suggestions, setSuggestions] = useState([]);

  // Filters 
  const [selectedTypes, setSelectedTypes] = useState(['restaurant']);
  const [minRating, setMinRating] = useState(0);
  const [radius, setRadius] = useState('1500');
  const [priceLevel, setPriceLevel] = useState(null);
  const [openNow, setOpenNow] = useState(false);

  // Hide header and request location
  useEffect(() => {
    navigation.setOptions({ headerShown: false });
    requestLocation();
  }, []);

  // When a place is selected, check if it's in favorites
  useEffect(() => {
    const checkFavoriteStatus = async () => {
      if (!selectedPlace?.place_id) return;

      try {
        const res = await api.get(`/favorites/${user.email}`);

        const isFav = res.data.some((p) => p.placeId === selectedPlace.place_id);
        setFavorite(isFav);
      } catch (err) {
        console.log('Error checking favorite status:', err);
        setFavorite(false);
      }
    };

    checkFavoriteStatus();
  }, [selectedPlace?.place_id]);

  // Load extra photos for the selected place
  useEffect(() => {
    const placeId = selectedPlace?.place_id;

    const loadPhotos = async () => {
      try {
        const res = await fetchPlaceDetails(placeId, GOOGLE_API_KEY);

        const photos = res?.photos ?? [];
        if (!photos.length) return;

        setSelectedPlace(prev => {
          if (!prev || prev.place_id !== placeId) return prev;

          return { ...prev, photos };
        });
      } catch (err) {
        console.log('Could not load additional photos', err);
      }
    };

    loadPhotos();
  }, [selectedPlace?.place_id]);

  // Request user location
  const requestLocation = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();

    if (status !== 'granted') {
      Alert.alert('Permission Denied', 'Location access is not available');
      return;
    }

    const loc = await Location.getCurrentPositionAsync({});
    const { latitude, longitude } = loc.coords;
    const newRegion = {
      latitude,
      longitude,
      latitudeDelta: 0.02,
      longitudeDelta: 0.02,
    };

    setRegion(newRegion);
    mapRef.current?.animateToRegion(newRegion, 500);
    fetchAllPlaces(newRegion);
  };

  // Fetch nearby places and apply filters
  const fetchAllPlaces = async (regionOverride = region) => {
    if (!regionOverride) return;

    setLoading(true);

    try {
      const { places: fetched, nextPageToken: token } = await fetchNearbyPlaces({
        location: `${regionOverride.latitude},${regionOverride.longitude}`,
        radius,
        types: selectedTypes,
        minPrice: priceLevel,
        maxPrice: priceLevel,
        openNow,
        apiKey: GOOGLE_API_KEY,
      });

      setNextPageToken(token || null);
      setRawPlaces(fetched);
      applyLocalFilters(fetched);
    } catch (err) {
      Alert.alert('Error', 'Failed to fetch places');
    } finally {
      setLoading(false);
    }
  };

  // Load more places
  const loadMorePlaces = async () => {
    if (!nextPageToken) return;

    setLoading(true);

    try {
      const { places: morePlaces, nextPageToken: newToken } = await fetchNextPage(nextPageToken, GOOGLE_API_KEY);
      const combined = [...rawPlaces, ...morePlaces];

      setRawPlaces(combined);
      applyLocalFilters(combined);
      setNextPageToken(newToken || null);
    } catch (err) {
      Alert.alert('Error', 'No additional results could be loaded');
    } finally {
      setLoading(false);
    }
  };

  // Apply rating filter
  const applyLocalFilters = (raw) => {
    if (minRating) {
      const filtered = raw.filter((p) => p.rating >= minRating);
      setPlaces(filtered);
    }
    else {
      setPlaces(raw);
    }
  };

  // Build a route from user's region to selected place
  const handleRoute = async () => {
    if (!region || !selectedPlace) return;

    try {
      const origin = `${region.latitude},${region.longitude}`;
      const destination = `${selectedPlace.geometry.location.lat},${selectedPlace.geometry.location.lng}`;

      const route = await fetchRoute({
        origin,
        destination,
        mode: travelMode,
        apiKey: GOOGLE_API_KEY,
      });

      if (!route || !route.legs || route.legs.length === 0) {
        Alert.alert('No Route Available', 'No route was found for the selected transportation mode');
        return;
      }

      const leg = route.legs[0];

      // Decode each step's polyline into lat/lng pairs
      const newSegments = leg.steps
      .filter((step) => step.polyline?.points)
      .map((step) => {
        const mode = step.travel_mode?.toLowerCase() || 'driving';

        try {
          const decoded = decodePolyline(step.polyline.points);

          const points = decoded.map(([latitude, longitude]) => ({
            latitude,
            longitude,
          }));

          return { mode, points };
        } catch (err) {
          console.warn('Failed to decode polyline for step:', step, err);
          return null;
        }
      })
      .filter(Boolean);

      setRouteSegments(newSegments);

      // Capture the line details
      let transitLine = null;
      if (travelMode === 'transit') {
        const transitStep = leg.steps.find(s => s.travel_mode === 'TRANSIT');

        if (transitStep?.transit_details) {
          const { line } = transitStep.transit_details;
          transitLine = {
            name: line.short_name || line.name,
            vehicle: line.vehicle.name,
          };
        }
      }

      setTravelInfo({
        distance: leg.distance.text,
        duration: leg.duration.text,
        transitLine,
        steps: leg.steps,
      });

      // Fit map to all polyline points
      const allPoints = newSegments.flatMap((s) =>
        s.points.map((point) => ({
          latitude: point.latitude,
          longitude: point.longitude,
        }))
      );
      mapRef.current?.fitToCoordinates(allPoints, {
        edgePadding: { top: 100, right: 100, bottom: 100, left: 100 },
        animated: true,
      });

      setSelectedPlace(null);

    } catch (err) {
      console.log(err)
      Alert.alert('Route Error', 'Failed to retrieve route data');
    }
  };

  // Reset filter to defaults
  const resetFilters = () => {
    setSelectedTypes(['restaurant']);
    setMinRating(0);
    setRadius('1500');
    setPriceLevel(null);
    setOpenNow(false);

    fetchAllPlaces();
  };

  // Toggle favorite for the selected place
  const toggleFavorite = async () => {
    if (!selectedPlace || !user?.email) return;

    try {
      if (favorite) {
        await api.delete(`/favorites/${user.email}/${selectedPlace.place_id}`);
        setFavorite(false);
      } else {
        await api.post('/favorites', {
          userId: user.email,
          placeId: selectedPlace.place_id,
          name: selectedPlace.name,
          address: selectedPlace.vicinity || selectedPlace.formatted_address || '',
          rating: selectedPlace.rating || null,
          photoReference: selectedPlace.photos?.[0]?.photo_reference || '',
          location: selectedPlace.geometry?.location || null,
        });
        setFavorite(true);
      }
    } catch (err) {
      console.error('Error toggling favorite:', err);
    }
  };

  // Fetch Google Autocomplete suggestions for the search bar
  const fetchAutocomplete = async (input) => {
    if (!input) return setSuggestions([]);

    try {
      const res = await fetch(
        `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${input}&key=${GOOGLE_API_KEY}`
      );
      const json = await res.json();
      setSuggestions(json.predictions || []);
    } catch (err) {
      console.error('Autocomplete error:', err);
    }
  };

  // Select a suggestion and fit the map there
  const onSelectSuggestion = async (item) => {
    Keyboard.dismiss();

    const details = await fetchPlaceDetails(item.place_id, GOOGLE_API_KEY);
    if (!details) return;

    const location = details.geometry.location;
    const newRegion = {
      latitude: location.lat,
      longitude: location.lng,
      latitudeDelta: 0.02,
      longitudeDelta: 0.02,
    };

    setRegion(newRegion);
    mapRef.current?.animateToRegion(newRegion, 500);
    fetchAllPlaces(newRegion);

    setSuggestions([]);
    setSearchText('');
    setShowSearchBar(false);
  };

  // If user taps "Search" with suggestions shown, pick the first suggestion
  const onSearch = () => {
    if (suggestions.length > 0) {
      onSelectSuggestion(suggestions[0]);
    } else {
      Alert.alert('Not Found', 'Please enter and select a location from the list');
    }
  };

  return (
    <Portal.Host>
      <View style={{ flex: 1 }}>
        {/* Search */}
        {showSearchBar && (
          <SearchBar
            searchText={searchText}
            setSearchText={(text) => {
              setSearchText(text);
              fetchAutocomplete(text);
            }}
            suggestions={suggestions}
            onSearch={onSearch}
            onSelectSuggestion={onSelectSuggestion}
          />
        )}

        {/* Filters modal */}
        <FilterModal
          visible={filterModalVisible}
          types={placeTypes}
          selectedTypes={selectedTypes}
          onToggleType={(type) =>
            setSelectedTypes((prev) =>
              prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
            )
          }
          minRating={minRating}
          onSetMinRating={setMinRating}
          radius={radius}
          setRadius={setRadius}
          priceLevel={priceLevel}
          setPriceLevel={setPriceLevel}
          openNow={openNow}
          setOpenNow={setOpenNow}
          onApply={() => {
            setFilterModalVisible(false);
            fetchAllPlaces();
          }}
          onClear={resetFilters}
          onClose={() => {
            setFilterModalVisible(false);
          }}
        />

         {/* Map */}
        {region && (
          <MapView ref={mapRef} style={{ flex: 1 }} initialRegion={region}>
             {/* User location marker */}
            <Marker coordinate={region} pinColor="blue" title="You are here" />

            {/* Place markers */}
            {places.map((p) => (
              <PlaceMarker key={p.place_id} place={p} onPress={setSelectedPlace} />
            ))}

            {/* Route segments */}
            {routeSegments.map((segment, idx) => (
              <Polyline
                key={idx}
                coordinates={segment.points}
                strokeWidth={5}
                strokeColor={
                  segment.mode === 'walking' ? '#9e9e9e' :
                  segment.mode === 'driving' ? '#1e88e5' :
                  segment.mode === 'transit' ? '#ff9800' :
                  segment.mode === 'bicycling' ? '#4caf50' :
                  '#000'
                }
                strokeDashPattern={segment.mode === 'walking' ? [10, 5] : undefined}
              />
            ))}
          </MapView>
        )}

        {/* Place details modal */}
        {selectedPlace && (
          <PlaceDetailsModal
            place={selectedPlace}
            visible={true}
            onClose={() => {setSelectedPlace(null)}}
            onFavoriteToggle={toggleFavorite}
            onRoutePress={handleRoute}
            isFavorite={favorite}
            travelMode={travelMode}
            setTravelMode={setTravelMode}
            apiKey={GOOGLE_API_KEY}
            userLocation={region}
          />
        )}

        {/* Route info */}
        <RouteManager
          travelInfo={travelInfo}
          mapRef={mapRef}
          userRegion={region}
          onCancel={() => {
            setRouteSegments([]);
            setTravelInfo(null);
            setSelectedPlace(null);
          }}
        />

        {/* Load more button */}
        {nextPageToken && (
          <TouchableOpacity
            style={{
              opacity: loading ? 0.5 : 1,
              position: 'absolute',
              bottom: 30,
              alignSelf: 'center',
              backgroundColor: '#000',
              paddingHorizontal: 20,
              paddingVertical: 10,
              borderRadius: 20,
              zIndex: 10,
            }}
            onPress={loadMorePlaces}
            disabled={loading}
          >
            <Text style={{ color: '#fff', fontWeight: '600' }}>
              {loading ? 'Loading...' : 'Load more'}
            </Text>
          </TouchableOpacity>
        )}

        {/* Options for search, location, filters */}
        <Portal>
          <FAB.Group
            open={fabOpen}
            icon={fabOpen ? 'close' : 'plus'}
            actions={[
              {
                icon: 'magnify',
                label: 'Search',
                onPress: () => setShowSearchBar(true)
              },
              {
                icon: 'map-marker',
                label: 'Location',
                onPress: requestLocation
              },
              {
                icon: 'filter',
                label: 'Filters',
                onPress: () => setFilterModalVisible(true)
              },
            ]}
            onStateChange={({ open }) => setFabOpen(open)}
          />
        </Portal>

        {/* Loader */}
        {loading && (
          <View style={{ position: 'absolute', top: 0, bottom: 0, right: 0, left: 0, backgroundColor: '#fff9', justifyContent: 'center', alignItems: 'center' }}>
            <ActivityIndicator size="large" color="#6d757eff" />
          </View>
        )}
      </View>
    </Portal.Host>
  );
}