import { View, Text } from 'react-native'
import React from 'react'
import { Tabs } from 'expo-router'
import Ionicons from '@expo/vector-icons/Ionicons';

// Defines the bottom tab navigation for the app
export default function TabLayout() {
  return (
    <Tabs screenOptions={{
      headerShown:false,
      tabBarActiveTintColor:'#000'
    }}>
      {/* My Trip tab */}
      <Tabs.Screen name="mytrip"
        options={{
          tabBarLabel:'My Trip',
          tabBarIcon:({color})=><Ionicons name="location-sharp" size={24} color={color} />
        }}
      />

      {/* Discover tab */}
      <Tabs.Screen name="discover"
        options={{
          tabBarLabel:'Discover',
          tabBarIcon:({color})=><Ionicons name="globe-sharp" size={24} color={color} />
        }}
      />

      {/* Favorites tab */}
      <Tabs.Screen name="favorites"
        options={{
          tabBarLabel:'Favorites',
          tabBarIcon:({color})=><Ionicons name="heart" size={24} color={color} />
        }}
      />

      {/* Profile tab */}
      <Tabs.Screen name="profile"
        options={{
          tabBarLabel:'Profile',
          tabBarIcon:({color})=><Ionicons name="people-circle" size={24} color={color} />
        }}
      />
    </Tabs>
  )
}