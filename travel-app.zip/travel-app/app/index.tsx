import { useContext } from "react";
import { Redirect } from "expo-router";
import { AuthContext } from "../context/AuthContext";

export default function Index() {
  const { user } = useContext(AuthContext);

  // If not logged in go to sign in
  if (!user) {
    return <Redirect href="/auth/sign-in" />;
  }

  // If logged in go to trips
  return <Redirect href="/home/mytrip" />;
}
