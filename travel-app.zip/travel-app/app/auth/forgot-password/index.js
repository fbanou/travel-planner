import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import Ionicons from '@expo/vector-icons/Ionicons';
import { AuthContext } from '../../../context/AuthContext';

// This screen allows a user to reset their password
export default function ForgotPasswordScreen() {
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { resetPassword } = useContext(AuthContext);

  // Handle reset password button press
  const handleResetPassword = async () => {
    if (!email || !newPassword) return Alert.alert('Error', 'Please fill all fields');

    if (newPassword.length < 8) {
      Alert.alert('Error', 'Password must be at least 8 characters long');
      return;
    }

    setLoading(true);

    // Call resetPassword function from AuthContext
    const res = await resetPassword(email, newPassword);

    if (res.success) {
      Alert.alert('Success', 'Password updated!');
      router.replace('/auth/sign-in');
    } else {
      if (res.message === 'User not found') {
        Alert.alert('User Not Found', 'No account exists with this email');
      } else {
        Alert.alert('Error', res.message);
      }
    }

    setLoading(false);
  };

  return (
    <View style={styles.container}>
      {/* Back button */}
      <TouchableOpacity onPress={() => router.back()}>
        <Ionicons name="arrow-back" size={24} color="black" />
      </TouchableOpacity>

      {/* Title & Subtitle */}
      <Text style={styles.title}>Reset your password</Text>
      <Text style={styles.subtitle}>Enter your email and a new password</Text>

      {/* Email input */}
      <View style={styles.inputWrapper}>
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Email"
          onChangeText={setEmail}
          value={email}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
        />
      </View>
      
      {/* Password input */}
      <View style={styles.inputWrapper}>
        <Text style={styles.label}>New Password</Text>
        <TextInput
          secureTextEntry={true}
          style={styles.input}
          placeholder="Enter Password"
          onChangeText={setNewPassword}
          value={newPassword}
        />
      </View>

      {/* Reset password button */}
      <TouchableOpacity
        style={styles.button}
        onPress={handleResetPassword}
        disabled={loading}
      >
        <Text style={styles.buttonText}>
          {loading ? 'Updating...' : 'Reset Password'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

// Styles for this screen
const styles = StyleSheet.create({
  container: { padding: 20, marginTop: 40 },
  title: { fontSize: 30, fontFamily: 'outfit-bold', marginVertical: 20 },
  subtitle: { 
    fontFamily: 'outfit',
    fontSize: 20,
    color: '#7d7d7d',
    marginBottom: 10,
  },
  input: {
    padding: 15,
    borderWidth: 1,
    borderRadius: 15,
    borderColor: '#7d7d7d',
    fontFamily: 'outfit',
    marginTop: 5,
  },
  button: {
    backgroundColor: '#000', padding: 20, borderRadius: 20, marginTop: 30,
  },
  buttonText: {
    color: '#fff', textAlign: 'center', fontFamily: 'outfit',
  },
  inputWrapper: {
    marginTop: 20,
  },
  label: {
    fontFamily: 'outfit',
  },
});
