import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  TextInput,
  Alert,
  TouchableOpacity,
  Text,
  StyleSheet,
  Platform,
} from 'react-native';
import { useNavigation, useRouter } from 'expo-router';
import { AuthContext } from '../../../context/AuthContext';
import * as AppleAuthentication from 'expo-apple-authentication';
import * as WebBrowser from 'expo-web-browser';
import * as Google from 'expo-auth-session/providers/google';
import * as AuthSession from 'expo-auth-session';

WebBrowser.maybeCompleteAuthSession();

// This screen allows users to sign in to the app
export default function LoginScreen() {
  const navigation = useNavigation();
  const router = useRouter();

  const { login, googleLogin, appleLogin } = useContext(AuthContext);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Google Auth Request
  /*const [request, response, promptAsync] = Google.useAuthRequest({
    clientId: '',
    redirectUri: AuthSession.makeRedirectUri({ useProxy: true }),
  }, { useProxy: true });*/

  // Hide header
  useEffect(() => {
    navigation.setOptions({ headerShown: false });
  }, []);

  // Google login response handler
  /*useEffect(() => {
    const doGoogleLogin = async () => {
      if (response?.type === 'success') {
        const { authentication } = response;
        console.log('Google Access Token:', authentication.accessToken);

        const result = await googleLogin(authentication.accessToken);

        if (result.success) {
          Alert.alert('Καλωσήρθες', 'Επιτυχής σύνδεση!');
          router.replace('home/mytrip');
        } else {
          Alert.alert('Google Login Failed', result.message);
        }
      }
    };

    doGoogleLogin();
  }, [response]);*/

  // Handle login
  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error','Please enter Email & Password');
      return;
    }

    const result = await login(email, password);

    if (result.success) {
      Alert.alert('Login success', 'Welcome, ' + (result?.user?.name || 'User') + ' !');
      router.replace('home/mytrip');
    } else {
      Alert.alert('Login error', result.message);
    }
  };

  // Handle Apple login
  const handleAppleLogin = async () => {
    try {
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });
      console.log('Apple Credential:', credential);

      const result = await appleLogin(credential.identityToken);

      if (result.success) {
        Alert.alert('Apple Login Success', 'Welcome, ' + (result?.user?.name || 'User') + ' !');
        router.replace('home/mytrip');
      } else {
        Alert.alert('Apple Login Failed', result.message);
      }
      
    } catch (e) {
      if (e.code === 'ERR_CANCELED') {
        console.log('Apple Login cancelled');
      } else {
        console.log('Apple Login error:', e);
        Alert.alert('Apple Login Error', e.message);
      }
    }
  };

  return (
    <View style={styles.container}>
      {/* Titles */}
      <Text style={styles.title}>Lets Sign You In</Text>
      <Text style={styles.subtitle}>Welcome Back</Text>
      <Text style={styles.subtitle}>You have been missed!</Text>

      {/* Email input */}
      <View style={styles.inputWrapper}>
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Email"
          onChangeText={setEmail}
          value={email}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
        />
      </View>

      {/* Password input */}
      <View style={styles.inputWrapper}>
        <Text style={styles.label}>Password</Text>
        <TextInput
          secureTextEntry={true}
          style={styles.input}
          placeholder="Enter Password"
          onChangeText={setPassword}
          value={password}
        />
      </View>

      {/* Forgot password link */}
      <TouchableOpacity onPress={() => router.push('auth/forgot-password')}>
        <Text style={styles.forgotText}>Forgot Password?</Text>
      </TouchableOpacity>

      {/* Sign In Button */}
      <TouchableOpacity onPress={handleLogin} style={styles.signInButton}>
        <Text style={styles.signInText}>Sign In</Text>
      </TouchableOpacity>

      {/* Divider */}
      <View style={styles.divider}>
        <Text style={{ color: '#7d7d7d' }}>──── OR ────</Text>
      </View>

      {/* Google Login */}
      {/*<TouchableOpacity
        onPress={() => promptAsync()}
        disabled={!request}
        style={styles.googleButton}
      >
        <View style={styles.googleContent}>
          <Image
            source={require('../../../assets/icons/google.jpg')}
            style={styles.googleLogo}
          />
          <Text style={styles.googleButtonText}>Sign in with Google</Text>
        </View>
      </TouchableOpacity>*/}

      {/* Apple Login (only show on iOS) */}
      {Platform.OS === 'ios' && (
        <AppleAuthentication.AppleAuthenticationButton
          buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN}
          buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.BLACK}
          cornerRadius={10}
          style={styles.appleButton}
          onPress={handleAppleLogin}
        />
      )}

      {/* Sign Up Link */}
      <TouchableOpacity
        onPress={() => router.replace('auth/sign-up')}
        style={styles.createAccountButton}
      >
        <Text style={styles.createAccountText}>Create Account</Text>
      </TouchableOpacity>
    </View>
  );
}

// Styles for this screen
const styles = StyleSheet.create({
  container: {
    padding: 25,
    paddingTop: 40,
    height: '100%',
    backgroundColor: '#fff',
  },
  title: {
    fontFamily: 'outfit-bold',
    fontSize: 30,
    marginTop: 30,
  },
  subtitle: {
    fontFamily: 'outfit',
    fontSize: 30,
    color: '#7d7d7d',
    marginTop: 10,
  },
  inputWrapper: {
    marginTop: 20,
  },
  label: {
    fontFamily: 'outfit',
  },
  input: {
    padding: 15,
    borderWidth: 1,
    borderRadius: 15,
    borderColor: '#7d7d7d',
    fontFamily: 'outfit',
    marginTop: 5,
  },
  signInButton: {
    padding: 20,
    borderRadius: 20,
    backgroundColor: '#000',
    marginTop: 30,
  },
  signInText: {
    fontFamily: 'outfit',
    color: '#fff',
    textAlign: 'center',
  },
  divider: {
    marginVertical: 20,
    alignItems: 'center',
  },
  appleButton: {
    width: '100%',
    height: 50,
    marginTop: 10,
  },
  createAccountButton: {
    padding: 20,
    borderRadius: 20,
    backgroundColor: '#fff',
    marginTop: 30,
    borderWidth: 1,
  },
  createAccountText: {
    color: '#000',
    textAlign: 'center',
  },
  googleButton: {
    backgroundColor: '#fff',
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  googleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  googleLogo: {
    width: 25,
    height: 25,
    marginRight: 5,
  },
  googleButtonText: {
    fontSize: 16,
    color: '#000',
    fontFamily: 'outfit',
  },
  forgotText: {
    color: '#007aff',
    fontFamily: 'outfit',
    marginTop: 10,
    marginBottom: 10,
    textAlign: 'left',
  },
});
