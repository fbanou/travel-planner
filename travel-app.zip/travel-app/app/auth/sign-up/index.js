import React, { useState, useContext } from 'react';
import {
  View,
  TextInput,
  Alert,
  TouchableOpacity,
  Text,
  StyleSheet,
} from 'react-native';
import { useRouter } from 'expo-router';
import { AuthContext } from '../../../context/AuthContext';

// This screen allows a new user to create an account
export default function RegisterScreen() {
  const router = useRouter();
  const { register } = useContext(AuthContext);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');

  // Handle registration logic
  const handleRegister = async () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Check all fields filled
    if (!email || !password || !fullName) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    // Validate email format
    if (!emailRegex.test(email)) {
      Alert.alert('Error', 'Invalid email address');
      return;
    }

    // Validate password strength
    if (password.length < 8) {
      Alert.alert('Error', 'Password must be at least 8 characters long');
      return;
    }

    // Call register from AuthContext
    const result = await register(email, password, fullName);

    if (result.success) {
      Alert.alert('Success', 'Registration successful!');
      router.replace('home/mytrip');
    } else {
      if (result.message === 'User already exists') {
        Alert.alert('User already exists', 'An account already exists with this email.');
      } else {
        Alert.alert('Error', result.message);
      }
    }
  };

  return (
    <View style={styles.container}>
      {/* Title */}
      <Text style={styles.title}>Create New Account</Text>

      <View style={{ marginTop: 50 }}>
        {/* Full Name input */}
        <Text style={styles.label}>Full Name</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Full Name"
          onChangeText={setFullName}
          value={fullName}
          autoCapitalize="words"
        />
      </View>

      <View style={{ marginTop: 20 }}>
        {/* Email input */}
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Email"
          onChangeText={setEmail}
          value={email}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
        />
      </View>

      <View style={{ marginTop: 20 }}>
        {/* Password input */}
        <Text style={styles.label}>Password</Text>
        <TextInput
          secureTextEntry={true}
          style={styles.input}
          placeholder="Enter Password"
          onChangeText={setPassword}
          value={password}
        />
      </View>

      {/* Register Button */}
      <TouchableOpacity onPress={handleRegister} style={styles.button}>
        <Text style={styles.buttonText}>Create Account</Text>
      </TouchableOpacity>

      {/* Divider */}
      <View style={styles.divider}>
        <Text style={{ color: '#7d7d7d' }}>──── OR ────</Text>
      </View>

      {/* Link to Sign In */}
      <TouchableOpacity
        onPress={() => router.replace('auth/sign-in')}
        style={[styles.button, styles.buttonOutline]}
      >
        <Text style={[styles.buttonText, { color: '#000' }]}>Sign In</Text>
      </TouchableOpacity>
    </View>
  );
}

// Styles for this screen
const styles = StyleSheet.create({
  container: {
    padding: 25,
    paddingTop: 40,
    height: '100%',
    backgroundColor: '#fff',
  },
  title: {
    fontFamily: 'outfit-bold',
    fontSize: 30,
    marginTop: 30,
  },
  label: {
    fontFamily: 'outfit',
  },
  input: {
    padding: 15,
    borderWidth: 1,
    borderRadius: 15,
    borderColor: '#7d7d7d',
    fontFamily: 'outfit',
  },
  button: {
    padding: 20,
    borderRadius: 20,
    backgroundColor: '#000',
    marginTop: 50,
  },
  buttonText: {
    fontFamily: 'outfit',
    color: '#fff',
    textAlign: 'center',
  },
  buttonOutline: {
    backgroundColor: '#fff',
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#000',
  },
  divider: {
    marginVertical: 20,
    alignItems: 'center',
  },
});
