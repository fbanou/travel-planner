import { Stack } from "expo-router";
import { useFonts } from "expo-font";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { View, ActivityIndicator } from "react-native";
import { useState, useContext } from "react";
import { AuthProvider, AuthContext } from "../context/AuthContext";
import { CreateTripContext } from "../context/CreateTripContext";
import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { Provider as PaperProvider } from 'react-native-paper';

function InnerLayout() {
  const { user, loading } = useContext(AuthContext);
  const [tripData, setTripData] = useState([]);

  // Load custom fonts used throughout the app
  const [fontsLoaded] = useFonts({
    "outfit": require("../assets/fonts/Outfit-Regular.ttf"),
    "outfit-medium": require("../assets/fonts/Outfit-Medium.ttf"),
    "outfit-bold": require("../assets/fonts/Outfit-Bold.ttf"),
  });

  if (loading || !fontsLoaded) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#000" />
      </View>
    );
  }

  // Provide tripData to all screens
  return (
    <CreateTripContext.Provider value={{ tripData, setTripData }}>
      <Stack screenOptions={{ headerShown: false }} />
    </CreateTripContext.Provider>
  );
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AuthProvider>
        <BottomSheetModalProvider>
          <PaperProvider>
            <InnerLayout />
          </PaperProvider>
        </BottomSheetModalProvider>
      </AuthProvider>
    </GestureHandlerRootView>
  );
}
