import { View, Text, Image } from 'react-native'
import React, { useContext, useEffect, useState } from 'react'
import { CreateTripContext } from '../../context/CreateTripContext';
import { AI_PROMPT } from '../../constants/Options';
import { useRouter } from 'expo-router';
import api from '../../services/api';
import { AuthContext } from '../../context/AuthContext';
import LottieView from 'lottie-react-native';

// This screen is responsible for generating a trip itinerary using AI
export default function GenerateTrip() {
    const { tripData } = useContext(CreateTripContext);
    const [loading, setLoading] = useState(false);
    const { user, token } = useContext(AuthContext);
    const router=useRouter();

    // Run AI generation as soon as screen loads
    useEffect(()=>{
        GenerateAiTrip()    
    },[])

    // Generate trip plan with AI and save it to backend
    const GenerateAiTrip = async () => {
        try {
            setLoading(true);

            // Construct prompt
            const FINAL_PROMPT = AI_PROMPT
                .replace('{location}', tripData?.locationInfo?.name)
                .replace('{totalDays}', tripData?.totalNoOfDays)
                .replace('{totalNights}', tripData?.totalNoOfDays - 1)
                .replace('{traveler}', tripData?.traveler?.title)
                .replace('{budget}', tripData?.budget);

            // Call AI API to generate plan
            const result = await api.post('/generate-ai/plan-trip', {
                prompt: FINAL_PROMPT,
            });

            console.log(result.data.result);
            const tripResp = JSON.parse(result.data.result);

            // Save generated trip to backend databas
            await api.post('/trips', {
                userEmail: user.email,
                tripPlan: tripResp,
                tripData: tripData,
            }, {
                headers: {
                Authorization: `Bearer ${token}`,
                }
            });

            setLoading(false);
            // Navigate to trips page
            router.push('home/mytrip');
        } catch (error) {
            console.error('Error generating trip:', error);
            setLoading(false);
        }
    };
    
    return (
        <View
            style={{
                flex: 1,
                backgroundColor: '#fff',
                justifyContent: 'center',
                alignItems: 'center',
                padding: 25,
                paddingTop: 75,
            }}
        >
            {/* Heading */}
            <Text
                style={{
                fontFamily: 'outfit-bold',
                fontSize: 35,
                textAlign: 'center',
                marginBottom: 10,
                }}
            >
                Please Wait...
            </Text>

            {/* Subtitle */}
            <Text
                style={{
                fontFamily: 'outfit-medium',
                fontSize: 20,
                textAlign: 'center',
                marginBottom: 20,
                color: '#333',
                }}
            >
                We are working to generate your dream trip
            </Text>

            {/* Loading animation */}
            <LottieView
                source={require('./../../assets/images/loading.json')}
                autoPlay
                loop
                style={{ width: 250, height: 250 }}
            />

            {/* Footer note */}
            <Text
                style={{
                fontFamily: 'outfit',
                fontSize: 18,
                textAlign: 'center',
                color: '#7d7d7d',
                marginTop: 20,
                }}
            >
                Do not go back
            </Text>
        </View>
    )
}