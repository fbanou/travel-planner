import { View, Text, TouchableOpacity } from 'react-native'
import { useContext, useEffect } from 'react'
import { useNavigation, useRouter } from 'expo-router';
import { CreateTripContext } from '../../context/CreateTripContext';
import moment from 'moment'

// This screen lets the user review their selected trip details before proceeding
export default function ReviewTrip() {
    const navigation=useNavigation();
    const router=useRouter();
    const {tripData, setTripData}=useContext(CreateTripContext);

    useEffect(()=>{
        // Configure navigation header
        navigation.setOptions({
            headerShown:true,
            headerTransparent:true,
            headerTitle:''
        })

        // Reset activities
        setTripData(prev => ({
            ...prev,
            activities: {},
        }));
    },[])

    return (
        <View style={{
            padding:25,
            paddingTop:75,
            backgroundColor:'#fff',
            height:'100%'
        }}>
            {/* Heading */}
            <Text style={{
                fontFamily:'outfit-bold',
                fontSize:35,
                marginTop:20
            }}>Review your trip</Text>

            {/* Info section */}
            <View style={{
                marginTop:20
            }}>
                <Text style={{
                    fontFamily:'outfit-bold',
                    fontSize:20
                }}>Before generating your trip, please review your selection</Text>

                {/* Destination */}
                <View style={{
                    marginTop: 20,
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 20,
                    alignItems: 'flex-start',
                    flexWrap: 'wrap'
                }}>
                    <Text style={{
                        fontSize:30
                    }}>📍</Text>
                    <View style={{ flexShrink: 1, flex: 1 }}>
                        <Text style={{
                            fontFamily:'outfit',
                            fontSize:20,
                            color:'#7d7d7d'
                        }}>Destination</Text>
                        <Text style={{
                            fontFamily: 'outfit-medium',
                            fontSize: 20,
                            flexWrap: 'wrap',
                            flexShrink: 1,
                        }}>
                            {tripData?.locationInfo?.name}
                        </Text>
                    </View>
                </View>

                {/* Travel Dates */}
                <View style={{
                    marginTop:25,
                    display:'flex',
                    flexDirection:'row',
                    gap:20
                }}>
                    <Text style={{
                        fontSize:30
                    }}>📆</Text>
                    <View>
                        <Text style={{
                            fontFamily:'outfit',
                            fontSize:20,
                            color:'#7d7d7d'
                        }}>Travel Date</Text>
                        <Text style={{
                            fontFamily:'outfit-medium',
                            fontSize:20
                        }}>{moment(tripData?.startDate).format('DD MMM')+" To "+moment(tripData?.endDate).format('DD MMM')+"  "}
                        ({tripData?.totalNoOfDays} days)</Text>
                    </View>
                </View>

                {/* Traveler */}
                <View style={{
                    marginTop:25,
                    display:'flex',
                    flexDirection:'row',
                    gap:20
                }}>
                    <Text style={{
                        fontSize:30
                    }}>🚍</Text>
                    <View>
                        <Text style={{
                            fontFamily:'outfit',
                            fontSize:20,
                            color:'#7d7d7d'
                        }}>Who is Traveling</Text>
                        <Text style={{
                            fontFamily:'outfit-medium',
                            fontSize:20
                        }}>{tripData?.traveler?.title}</Text>
                    </View>
                </View>

                {/* Budget */}
                <View style={{
                    marginTop:25,
                    display:'flex',
                    flexDirection:'row',
                    gap:20
                }}>
                    <Text style={{
                        fontSize:30
                    }}>💰</Text>
                    <View>
                        <Text style={{
                            fontFamily:'outfit',
                            fontSize:20,
                            color:'#7d7d7d'
                        }}>Budget</Text>
                        <Text style={{
                            fontFamily:'outfit-medium',
                            fontSize:20
                        }}>{tripData?.budget}</Text>
                    </View>
                </View>
            </View>

            {/* Action buttons */}
            <View style={{
                marginTop: 50,
                gap: 15,
            }}>
                {/* Custom Trip Button */}
                <TouchableOpacity 
                    onPress={() => router.replace('/create-trip/custom-trip')}
                    style={{
                        paddingVertical: 15,
                        paddingHorizontal: 20,
                        backgroundColor: '#000',
                        borderRadius: 12,
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: '100%',
                    }}
                >
                    <Text style={{
                        color: '#fff',
                        fontFamily: 'outfit-medium',
                        fontSize: 18
                    }}>Build My Trip</Text>
                </TouchableOpacity>

                {/* AI Trip Button */}
                <TouchableOpacity 
                    onPress={() => router.replace('/create-trip/generate-trip')}
                    style={{
                        paddingVertical: 15,
                        paddingHorizontal: 20,
                        borderWidth: 2,
                        borderColor: '#000',
                        borderRadius: 12,
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: '#fff',
                        width: '100%',
                    }}
                >
                    <Text style={{
                        color: '#000',
                        fontFamily: 'outfit-medium',
                        fontSize: 18
                    }}>🤖 Build My Trip With AI</Text>
                </TouchableOpacity>

            </View>
        </View>
    )
}