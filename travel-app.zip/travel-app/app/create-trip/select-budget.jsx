import { View, Text, FlatList, TouchableOpacity, Alert } from 'react-native'
import React, { useContext, useEffect, useState } from 'react'
import { useNavigation, useRouter } from 'expo-router';
import { SelectBudgetOptions } from '../../constants/Options';
import OptionCard from './../../components/CreateTrip/OptionCard'
import { CreateTripContext } from '../../context/CreateTripContext';

// The user choose a budget profile for the trip
export default function SelectBudget() {
    const navigation=useNavigation();
    const router=useRouter();

    const [selectedOption, setSelectedOption]=useState();

    // Access and update trip data
    const {tripData, setTripData}=useContext(CreateTripContext);

    // Configure header
    useEffect(()=>{
        navigation.setOptions({
            headerShown:true,
            headerTransparent:true,
            headerTitle:''
        })
    },[])

    // Add selection into context
    useEffect(() => {
        if (selectedOption) {
            setTripData({
                ...tripData,
                budget: selectedOption?.title,
            });
        }
    }, [selectedOption]);

    // Continue to review screen
    const onClickContinue=()=>{        
        if(!selectedOption) {
            Alert.alert('Error', 'Select Your Budget');
            return;
        }

        router.push('/create-trip/review-trip');
    }

    return (
        <View style={{
            padding:25,
            paddingTop:75,
            backgroundColor:'#fff',
            height:'100%'
        }}>
            {/* Title */}
            <Text style={{
                fontFamily:'outfit-bold',
                fontSize:35,
                marginTop:20
            }}>Budget</Text>

            {/* Subtitle and options list */}
            <View style={{
                marginTop:20
            }}>
                <Text style={{
                    fontFamily:'outfit-bold',
                    fontSize:20,
                }}>Choose spending habits for your trip</Text>

                {/* Budget options as cards */}
                <FlatList
                data={SelectBudgetOptions}
                renderItem={({item,index})=>(
                    <TouchableOpacity 
                    onPress={()=>setSelectedOption(item)}
                    style={{
                        marginVertical:10
                    }}>
                        <OptionCard option={item} selectedOption={selectedOption} />
                    </TouchableOpacity>
                )}
                />
            </View>

            {/* Continue button */}
            <TouchableOpacity 
                onPress={()=>onClickContinue()}
                style={{
                    padding:15,
                    backgroundColor:'#000',
                    borderRadius:15,
                    marginTop:20
                }}
            >
                <Text style={{
                    textAlign:'center',
                    color:'#fff',
                    fontFamily:'outfit-medium',
                    fontSize:20
                }}>Continue</Text>
                
            </TouchableOpacity>
        </View>
    )
}