import React, { useContext, useState, useEffect } from 'react';
import { SafeAreaView, View, Alert } from 'react-native';
import { useRouter, useNavigation } from 'expo-router';
import { AuthContext } from '../../context/AuthContext';
import { CreateTripContext } from '../../context/CreateTripContext';
import DayTimeline from '../../components/TripPlan/DayTimeline';
import TripCalendar from '../../components/TripPlan/TripCalendar';
import TripFooter from '../../components/TripPlan/TripFooter';
import api from '../../services/api';

// This screen displays the trip itinerary and allows users to add activities in their plan
export default function TripItinerary() {
  const router = useRouter();
  const navigation = useNavigation();
  const { user, token } = useContext(AuthContext);
  const { tripData, setTripData } = useContext(CreateTripContext);
  const [showCalendar, setShowCalendar] = useState(false);

  // Show header bar
  useEffect(() => {
    navigation.setOptions({ headerShown: true, headerTransparent: true, headerTitle: '' });
  }, []);

  // Delete an activity from a day
  const handleDelete = (day, index) => {
    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete this activity?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            const updated = [...(tripData.activities?.[day] || [])];
            updated.splice(index, 1);
            setTripData(prev => ({
              ...prev,
              activities: {
                ...prev.activities,
                [day]: updated,
              },
            }));
          },
        },
      ]
    );
  };

  // Save the trip to backend
  const saveTrip = async () => {
    try {
      // Ensure activities for each day are sorted
      const sortedActivities = {};
      for (const [day, acts] of Object.entries(tripData.activities || {})) {
        sortedActivities[day] = [...acts].sort((a, b) => a.time.localeCompare(b.time));
      }

      // Update context with sorted activities
      setTripData(prev => ({ ...prev, activities: sortedActivities }));

      // API call to save trip
      const res = await api.post('/trips/create', {
        userEmail: user.email,
        tripData: {
          ...tripData,
          activities: sortedActivities,
        },
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });

      if (res.data.success) {
        Alert.alert('Save Trip', 'Trip saved successfully!');
        router.push('home/mytrip');
      } else {
        throw new Error('Failed to save trip');
      }
    } catch (err) {
      Alert.alert('Error', err.message);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <View style={{ flex: 1, paddingHorizontal: 25 }}>
        {/* Switch between Calendar and Timeline */}
        {showCalendar ? (
          <TripCalendar tripData={tripData} />
        ) : (
          <DayTimeline tripData={tripData} onDelete={handleDelete} />
        )}
      </View>

      {/* Footer controls */}
      <TripFooter
        showCalendar={showCalendar}
        onToggle={() => setShowCalendar(prev => !prev)}
        onSave={saveTrip}
        location={tripData.locationInfo?.cordinates}
      />
    </SafeAreaView>
  );
}
