import React, { useState, useContext, useEffect } from 'react';
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Keyboard
} from 'react-native';
import { useNavigation, useRouter } from 'expo-router';
import { CreateTripContext } from './../../context/CreateTripContext';
import MapView, { Marker } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';

// The user search for a destination using Google Places
export default function SearchPlace() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);

  const [selectedCoords, setSelectedCoords] = useState(null);
  const [selectedPlaceName, setSelectedPlaceName] = useState('');

  const [mapRegion, setMapRegion] = useState(null);

  const navigation = useNavigation();
  const router = useRouter();
  const { tripData, setTripData } = useContext(CreateTripContext);

  // Show a transparent header
  useEffect(() => {
    navigation.setOptions({
      headerShown: true,
      headerTransparent: true,
      headerTitle: '',
    });
  }, []);

  // Fetch autocomplete predictions
  const fetchPlaces = async (input) => {
    if (!input) return;

    try {
      const apiKey = process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY;
      const res = await fetch(
        `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${input}&key=${apiKey}`
      );
      const json = await res.json();
      setResults(json.predictions || []);
    } catch (error) {
      console.error('Error fetching places:', error);
    }
  };

  // Fetch place details
  const fetchPlaceDetails = async (placeId) => {
    const apiKey = process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY;
    const res = await fetch(
      `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&key=${apiKey}`
    );
    const json = await res.json();
    return json.result;
  };

  // When a user picks a prediction
  const handlePlaceSelect = async (item) => {
    const details = await fetchPlaceDetails(item.place_id);
    const coords = details.geometry.location;

    // Add selection into trip context
    setTripData({
      ...tripData,
      locationInfo: {
        name: item.description,
        cordinates: coords,
        photoRef: details?.photos?.[0]?.photo_reference,
        url: details?.url,
      },
    });

    setSelectedCoords({
      latitude: coords.lat,
      longitude: coords.lng,
    });
    setSelectedPlaceName(item.description);
    setResults([]);
    setQuery(item.description);

    // Center the map preview on the selected place
    setMapRegion({
      latitude: coords.lat,
      longitude: coords.lng,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });

    Keyboard.dismiss();
  };

  // Go to next page
  const handleContinue = () => {
    router.push('/create-trip/select-traveller');
  };

  // Zoom controls for the map preview
  const zoomIn = () => {
    if (mapRegion) {
      setMapRegion({
        ...mapRegion,
        latitudeDelta: mapRegion.latitudeDelta * 0.5,
        longitudeDelta: mapRegion.longitudeDelta * 0.5,
      });
    }
  };

  const zoomOut = () => {
    if (mapRegion) {
      setMapRegion({
        ...mapRegion,
        latitudeDelta: mapRegion.latitudeDelta * 2,
        longitudeDelta: mapRegion.longitudeDelta * 2, 
      });
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1, backgroundColor: '#f9f9f9' }}
    >
      <FlatList
        data={results}
        keyExtractor={(item) => item.place_id}
        keyboardShouldPersistTaps="handled"
        // Header with title and search box
        ListHeaderComponent={
          <View style={{ padding: 24, paddingTop: 80 }}>
            <Text style={{ fontSize: 24, fontWeight: '600', marginBottom: 16, color: '#333', marginTop: 30 }}>
              Select Your Destination
            </Text>

            <TextInput
              placeholder="Search location..."
              value={query}
              onChangeText={(text) => {
                setQuery(text);
                fetchPlaces(text);
              }}
              style={{
                backgroundColor: '#fff',
                borderRadius: 12,
                padding: 14,
                paddingHorizontal: 18,
                fontSize: 16,
                shadowColor: '#000',
                shadowOpacity: 0.05,
                shadowRadius: 6,
                elevation: 2,
              }}
            />
          </View>
        }

        // Each autocomplete suggestion row
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => handlePlaceSelect(item)}
            style={{
              paddingVertical: 12,
              paddingHorizontal: 24,
              backgroundColor: '#fff',
              borderBottomWidth: 1,
              borderBottomColor: '#f0f0f0',
            }}
          >
            <Text style={{ fontSize: 16 }}>{item.description}</Text>
          </TouchableOpacity>
        )}

        // Footer
        ListFooterComponent={
          selectedCoords && (
            <View style={{ padding: 24 }}>
              <Text style={{ fontSize: 16, fontWeight: '500', marginBottom: 8 }}>Preview:</Text>

              {/* Map preview */}
              <MapView
                style={{ width: '100%', height: 400, borderRadius: 12 }}
                region={mapRegion}
                onRegionChangeComplete={(region) => setMapRegion(region)}
              >
                <Marker coordinate={selectedCoords} title={selectedPlaceName} />
              </MapView>

              {/* Zoom buttons */}
              <View
                style={{
                  position: 'absolute',
                  right: 35,
                  zIndex: 10,
                  bottom: 115,
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 12,
                }}
              >
                {/* Zoom In */}
                <TouchableOpacity
                  onPress={zoomIn}
                  style={{
                    backgroundColor: '#fff',
                    width: 45,
                    height: 45,
                    borderRadius: 25,
                    justifyContent: 'center',
                    alignItems: 'center',
                    shadowColor: '#000',
                    shadowOpacity: 0.2,
                    shadowOffset: { width: 0, height: 2 },
                    shadowRadius: 4,
                    elevation: 6,
                  }}
                >
                  <Ionicons name="add-sharp" size={24} color="black" />
                </TouchableOpacity>

                {/* Zoom Out */}
                <TouchableOpacity
                  onPress={zoomOut}
                  style={{
                    backgroundColor: '#fff',
                    width: 45,
                    height: 45,
                    borderRadius: 25,
                    justifyContent: 'center',
                    alignItems: 'center',
                    shadowColor: '#000',
                    shadowOpacity: 0.2,
                    shadowOffset: { width: 0, height: 2 },
                    shadowRadius: 4,
                    elevation: 6,
                  }}
                >
                  <Ionicons name="remove-sharp" size={24} color="black" />
                </TouchableOpacity>
              </View>

              {/* Continue Button */}
              <TouchableOpacity
                onPress={handleContinue}
                style={{
                  backgroundColor: '#000',
                  padding: 16,
                  borderRadius: 12,
                  marginTop: 24,
                  alignItems: 'center',
                  shadowColor: '#000',
                  shadowOpacity: 0.15,
                  shadowRadius: 6,
                  elevation: 3,
                }}
              >
                <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16 }}>Continue</Text>
              </TouchableOpacity>
            </View>
          )
        }
      />
    </KeyboardAvoidingView>
  );
}