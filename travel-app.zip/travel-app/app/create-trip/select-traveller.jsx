import { View, Text, FlatList, TouchableOpacity, Alert } from 'react-native'
import React, { useContext, useEffect, useState } from 'react'
import { useNavigation, useRouter } from 'expo-router'
import { SelectTravelerList } from './../../constants/Options'
import OptionCard from '../../components/CreateTrip/OptionCard';
import { CreateTripContext } from '../../context/CreateTripContext';

// The user choose who is traveling (solo, couple, family, friends, etc.)
export default function SelectTraveller() {
    const navigation=useNavigation();
    const router=useRouter();

    const [selectedTraveler, setSelectedTraveler]=useState();

    // Access and update trip data
    const {tripData, setTripData}=useContext(CreateTripContext);

    // Configure header
    useEffect(()=>{
        navigation.setOptions({
            headerShown:true,
            headerTransparent:true,
            headerTitle:''
        })
    },[])

    // Add chosen traveler into context whenever it changes
    useEffect(()=>{
        setTripData({...tripData, 
            traveler:selectedTraveler
        })
    },[selectedTraveler]);

    useEffect(()=>{
        console.log(tripData);
    },[tripData]);

    // Continue to date selection
    const onClickContinue=()=>{
        if(!selectedTraveler) {
            Alert.alert('Error', 'Select Travelers');
            return;
        }

        router.push('/create-trip/select-dates');
    }

    return (
        <View style={{
            padding:25,
            paddingTop:75,
            backgroundColor:'#fff',
            height:'100%'
        }}>
            {/* Title */}
            <Text style={{
                fontSize:35,
                fontFamily:'outfit-bold',
                marginTop:20
            }}>Who’s Travelling</Text>

            {/* Subtitle and options list */}
            <View style={{
                marginTop:20
            }}>
                <Text style={{
                    fontFamily:'outfit-bold',
                    fontSize:23
                }}>Choose your travelers</Text>

                {/* Traveler options */}
                <FlatList
                    data={SelectTravelerList}

                    renderItem={({item, index})=>(
                        <TouchableOpacity 
                        onPress={()=>setSelectedTraveler(item)}
                        style={{
                            marginVertical:10
                        }}>
                            <OptionCard option={item} selectedOption={selectedTraveler} />
                        </TouchableOpacity>
                    )}
                />
            </View>

            {/* Continue button */}
            <TouchableOpacity 
                onPress={()=>onClickContinue()}
                style={{
                    padding:15,
                    backgroundColor:'#000',
                    borderRadius:15,
                    marginTop:20
                }}
            >
                <Text style={{
                    textAlign:'center',
                    color:'#fff',
                    fontFamily:'outfit-medium',
                    fontSize:20
                }}>Continue</Text>
                
            </TouchableOpacity>
        </View>
    )
}