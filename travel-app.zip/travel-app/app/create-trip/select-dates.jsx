import { View, Text, TouchableOpacity, Alert } from 'react-native'
import React, { useContext, useEffect, useState } from 'react'
import { useNavigation, useRouter } from 'expo-router';
import moment from 'moment';
import { CreateTripContext } from '../../context/CreateTripContext';
import CalendarPicker from 'react-native-calendar-picker';

// The user pick a start and end date for the trip using a range calendar
export default function SelectDates() {
    const navigation=useNavigation();
    const router=useRouter();

    const [startDate, setStartDate]=useState();
    const [endDate, setEndDate]=useState();

    // Access and update trip data
    const {tripData, setTripData}=useContext(CreateTripContext);

    // Show transparent header
    useEffect(()=>{
        navigation.setOptions({
            headerShown:true,
            headerTransparent:true,
            headerTitle:''
        })
    },[])

    // Handle range selection from CalendarPicker
    const onDateChange=(date, type)=>{
        console.log(date,type);

        if(type === 'START_DATE') {
            setStartDate(moment(date))
        }
        else {
            setEndDate(moment(date))
        }
    }

     // Continue button handler
    const onDateSelectionContinue=()=>{
        if(!startDate || !endDate) {
            Alert.alert('Error', 'Please select Start and End Date');
            return;
        }

        // Compute day count
        const totalNoOfDays=endDate.diff(startDate, 'days') + 1;
        console.log(totalNoOfDays);
        
        // Add to trip context
        setTripData({
            ...tripData,
            startDate: startDate,
            endDate: endDate,
            totalNoOfDays: totalNoOfDays
        });

        router.push('/create-trip/select-budget')
    }

    return (
        <View style={{
            padding:25,
            paddingTop:75,
            backgroundColor:'#fff',
            height:'100%'
        }}>
            {/* Title */}
            <Text style={{
                fontFamily:'outfit-bold',
                fontSize:35,
                marginTop:20
            }}>Travel Dates</Text>

            {/* Calendar Range Picker */}
            <View style={{
                marginTop:30
            }}>
                <CalendarPicker 
                onDateChange={onDateChange} 
                allowRangeSelection={true}
                minDate={new Date()}
                selectedRangeStyle={{
                    backgroundColor:'#000'
                }}
                selectedDayTextStyle={{
                    color:'#fff'
                }} 
                />
            </View>
            
            {/* Continue Button */}
            <TouchableOpacity 
            onPress={onDateSelectionContinue}
            style={{
                padding:15,
                backgroundColor:'#000',
                borderRadius:15,
                marginTop:35
            }}>
                <Text style={{
                    textAlign:'center',
                    color:'#fff',
                    fontFamily:'outfit-medium',
                    fontSize:20
                }}>Continue</Text>
                
            </TouchableOpacity>
        </View>
    )
}
