import React, { useState, useContext, useEffect } from 'react';
import {
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
} from 'react-native';
import { useRouter, useLocalSearchParams, useNavigation } from 'expo-router';
import { CreateTripContext } from '../../context/CreateTripContext';
import moment from 'moment';
import DateTimePicker from '@react-native-community/datetimepicker';

// This screen allows the user to add a new activity or edit an existing one
export default function AddEditActivity() {
  const { tripData, setTripData } = useContext(CreateTripContext);
  const router = useRouter();
  // Params passed from navigation
  const { day, editIndex } = useLocalSearchParams();
  const navigation = useNavigation();
  const [showTimePicker, setShowTimePicker] = useState(false);

  // If editing, retrieve the existing activity for that day/index
  const existingActivity =
    editIndex !== undefined && tripData.activities?.[day]
      ? tripData.activities[day][Number(editIndex)]
      : null;

  const [time, setTime] = useState(existingActivity?.time || '');
  const [title, setTitle] = useState(existingActivity?.title || '');
  const [description, setDescription] = useState(existingActivity?.description || '');

  // Configure navigation header
  useEffect(() => {
    navigation.setOptions({
      headerShown: true,
      headerTransparent: true,
      headerTitle: '',
    });
  }, []);

  // Validate if time is in HH:mm format
  const validateTime = (t) => moment(t, 'HH:mm', true).isValid();

  // Save handler (create or update activity)
  const handleSave = () => {
    if (!title) {
      Alert.alert('Error', 'Please fill in the title');
      return;
    }

    // Validate time format if provided
    if (time && !validateTime(time)) {
      Alert.alert('Error', 'Time must be in HH:mm format');
      return;
    }

    // Construct new activity object
    const newActivity = {
      // Keep any existing fields if editing
      ...(existingActivity || {}),
      time,
      title,
      description,
    };

    // Update tripData context
    setTripData((prev) => {
      const activitiesForDay = prev.activities?.[day] ? [...prev.activities[day]] : [];

      if (editIndex !== undefined) {
        // Replace existing activity if editing
        activitiesForDay[Number(editIndex)] = newActivity;
      } else {
        // Add new activity
        activitiesForDay.push(newActivity);
      }

      // Sort activities by time (activities without time go last)
      activitiesForDay.sort((a, b) => {
        if (!a.time) return 1;
        if (!b.time) return -1;
        return a.time.localeCompare(b.time);
      });

      // Return updated tripData
      return {
        ...prev,
        activities: {
          ...prev.activities,
          [day]: activitiesForDay,
        },
      };
    });

    // Navigate back after saving
    router.back();
  };

  return (
    // Dismiss keyboard when tapping outside input
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.container}
      >
        {/* Screen heading */}
        <Text style={styles.heading}>
          {editIndex !== undefined ? 'Edit Activity' : 'Add Activity'} - Day {day}
        </Text>

        {/* Time Picker */}
        <Text style={styles.label}>Time (optional)</Text>
        <TouchableOpacity onPress={() => setShowTimePicker(true)} style={styles.timePickerButton}>
          <Text style={styles.timePickerButtonText}>
            {time ? time : 'Select Time'}
          </Text>
        </TouchableOpacity>

        {/* DateTime Picker */}
        {showTimePicker && (
          <DateTimePicker
            mode="time"
            value={time ? moment(time, 'HH:mm').toDate() : new Date()}
            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
            themeVariant="light"
            onChange={(event, selectedDate) => {
              if (Platform.OS === 'android') setShowTimePicker(false);
              if (selectedDate) {
                const formatted = moment(selectedDate).format('HH:mm');
                setTime(formatted);
              }
            }}
          />
        )}

        {/* Title Input */}
        <Text style={styles.label}>Title</Text>
        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="Activity title"
          style={styles.input}
        />

        {/* Description Input */}
        <Text style={styles.label}>Description (optional)</Text>
        <TextInput
          value={description}
          onChangeText={setDescription}
          placeholder="Details..."
          style={[styles.input, { height: 80 }]}
          multiline
        />

        {/* Save Button */}
        <TouchableOpacity onPress={handleSave} style={styles.saveBtn}>
          <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16 }}>Save</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

// Styles for the screen
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 100,
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 26,
    fontWeight: '700',
    marginBottom: 10,
    color: '#000',
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
    marginTop: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
    marginBottom: 10,
  },
  timePickerButton: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 12,
    padding: 14,
    backgroundColor: '#f5f5f5',
    alignItems: 'center',
    marginBottom: 20,
  },
  timePickerButtonText: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
  },
  saveBtn: {
    backgroundColor: '#000',
    marginTop: 30,
    padding: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
});
