import React, { useEffect, useState, useContext } from 'react';
import { View, TouchableOpacity, Text, ActivityIndicator, Alert } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { useLocalSearchParams, useNavigation } from 'expo-router';
import { CreateTripContext } from '../../context/CreateTripContext';
import FilterModal from '../../components/MapScreen/FilterModal';
import PlaceDetailsModal from '../../components/MapScreen/PlaceDetails';
import DayTimePickerModal from '../../components/MapScreen/DayTimePicker';
import { fetchNearbyPlaces, fetchNextPage,  fetchPlaceDetails } from '../../services/GooglePlaceApi';
import { placeTypes } from '../../constants/placeTypes';
import { FontAwesome } from '@expo/vector-icons';

// This screen displays a map that allows users to explore activities to add to their plan
export default function MapScreenContent() {
  // Get trip location from navigation params
  const { latitude, longitude } = useLocalSearchParams();
  const lat = parseFloat(latitude);
  const lng = parseFloat(longitude);
  const GOOGLE_API_KEY = process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY;

  const navigation = useNavigation();
  const { tripData, setTripData } = useContext(CreateTripContext);

  const [places, setPlaces] = useState([]);
  const [rawPlaces, setRawPlaces] = useState([]);
  const [nextPageToken, setNextPageToken] = useState(null);
  const [loading, setLoading] = useState(false);

  const [selectedPlace, setSelectedPlace] = useState(null);
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [placeInfoModalVisible, setPlaceInfoModalVisible] = useState(false);
  const [dayTimeModalVisible, setDayTimeModalVisible] = useState(false);

  // Filters
  const [selectedTypes, setSelectedTypes] = useState(['restaurant']);
  const [minRating, setMinRating] = useState(0);
  const [priceLevel, setPriceLevel] = useState(null);
  const [openNow, setOpenNow] = useState(false);
  const [radius, setRadius] = useState('1500');

  const [selectedDay, setSelectedDay] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [activities, setActivities] = useState(tripData.activities || {});
  const tripDays = Array.from({ length: tripData.totalNoOfDays }, (_, index) => `Day ${index + 1}`);

  // Fetch places on first render
  useEffect(() => {
    fetchPlaces();
  }, []);

  // Configure navigation header
  useEffect(() => {
    navigation.setOptions({ headerShown: true, headerTransparent: true, headerTitle: '' });
  }, [navigation]);

  useEffect(() => {
    setTripData((prev) => ({ ...prev, activities }));
  }, [activities]);

  // When a place is selected, fetch additional photos
  useEffect(() => {
      const placeId = selectedPlace?.place_id;

      const loadPhotos = async () => {
        try {
          const res = await fetchPlaceDetails(placeId, GOOGLE_API_KEY);
          const photos = res?.photos ?? [];
          if (!photos.length) return;

          // Update selected place with photos
          setSelectedPlace(prev => {
            if (!prev || prev.place_id !== placeId) return prev;

            return { ...prev, photos };
          });
        } catch (err) {
          console.log('Could not load additional photos', err);
        }
      };

      loadPhotos();
  }, [selectedPlace?.place_id]);

  // Add a place as activity for a selected day/time
  const handleAddActivity = (day, activity) => {
    const dayKey = String(day).replace(/\D/g, '');
    setActivities((prev) => {
      const updated = { ...prev };
      if (!updated[dayKey]) updated[dayKey] = [];
      updated[dayKey].push(activity);
      updated[dayKey].sort((a, b) => a.time.localeCompare(b.time));
      return updated;
    });
  };

  // Apply rating filter
  const applyLocalFilters = (raw) => {
    if (minRating) {
      const filtered = raw.filter((p) => p.rating >= minRating);
      setPlaces(filtered);
    }
    else {
      setPlaces(raw);
    } 
  };

  // Fetch nearby places from Google API
  const fetchPlaces = async (regionOverride = { latitude: lat, longitude: lng }) => {
    if (!regionOverride) return;

    setLoading(true);
    try {
      const { places: fetched, nextPageToken: token } = await fetchNearbyPlaces({
        location: `${regionOverride.latitude},${regionOverride.longitude}`,
        radius,
        types: selectedTypes,
        minPrice: priceLevel,
        maxPrice: priceLevel,
        openNow,
        apiKey: GOOGLE_API_KEY,
      });

      setNextPageToken(token || null);
      setRawPlaces(fetched);
      applyLocalFilters(fetched);
    } catch (err) {
      Alert.alert('Error', 'Failed to fetch places');
    } finally {
      setLoading(false);
    }
  };

  // Load additional places
  const loadMorePlaces = async () => {
    if (!nextPageToken) return;

    setLoading(true);
    try {
      const { places: morePlaces, nextPageToken: newToken } = await fetchNextPage(nextPageToken, GOOGLE_API_KEY);
      const combined = [...rawPlaces, ...morePlaces];

      setRawPlaces(combined);
      applyLocalFilters(combined);
      setNextPageToken(newToken || null);
    } catch (err) {
      Alert.alert('Error', 'No additional results could be loaded');
    } finally {
      setLoading(false);
    }
  };

  // Reset filters to defaults
  const resetFilters = () => {
    setSelectedTypes(['restaurant']);
    setMinRating(0);
    setRadius('1500');
    setPriceLevel(null);
    setOpenNow(false);

    fetchPlaces();
  };

  return (
    <View style={{ flex: 1 }}>
      {/* Filter Button */}
      <TouchableOpacity
        style={{
          position: 'absolute',
          bottom: 40,
          alignSelf: 'center',
          backgroundColor: '#fff',
          paddingVertical: 12,
          paddingHorizontal: 20,
          borderRadius: 25,
          zIndex: 100,
          elevation: 4,
          flexDirection: 'row',
          alignItems: 'center',
        }}
        onPress={() => setFilterModalVisible(true)}
      >
        <FontAwesome name="filter" size={24} color="black" style={{ marginRight: 6 }} />
        <Text style={{ fontWeight: 'bold', fontSize: 16, color: '#000' }}>
          Filters
        </Text>
      </TouchableOpacity>

      {/* Map with markers for trip and places */}
      <MapView
        style={{ flex: 1 }}
        initialRegion={{
          latitude: lat,
          longitude: lng,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        }}
      >
        {/* Marker for trip location */}
        <Marker
          coordinate={{ latitude: lat, longitude: lng }}
          title="Trip Location"
          pinColor="blue"
        />

        {/* Markers for fetched places */}
        {places.map((place) => (
          <Marker
            key={place.place_id}
            coordinate={{
              latitude: place.geometry.location.lat,
              longitude: place.geometry.location.lng,
            }}
            onPress={() => {
              setSelectedPlace(place);
              setPlaceInfoModalVisible(true);
            }}
          />
        ))}
      </MapView>

      {loading && (
        <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, justifyContent: 'center', alignItems: 'center', backgroundColor: '#ffffff99' }}>
          <ActivityIndicator size="large" color="#6d757eff" />
        </View>
      )}

      {/* Load more button */}
      {nextPageToken && (
        <TouchableOpacity
          style={{
            position: 'absolute',
            bottom: 100,
            alignSelf: 'center',
            backgroundColor: '#000',
            paddingHorizontal: 20,
            paddingVertical: 10,
            borderRadius: 20,
            zIndex: 10,
            opacity: loading ? 0.5 : 1,
          }}
          onPress={loadMorePlaces}
          disabled={loading}
        >
          <Text style={{ color: '#fff', fontWeight: '600' }}>
            {loading ? 'Loading...' : 'Load more'}
          </Text>
        </TouchableOpacity>
      )}

      {/* Filters Modal */}
      <FilterModal
        visible={filterModalVisible}
        types={placeTypes}
        selectedTypes={selectedTypes}
        onToggleType={(type) =>
          setSelectedTypes((prev) =>
            prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
          )
        }
        minRating={minRating}
        onSetMinRating={setMinRating}
        radius={radius}
        setRadius={setRadius}
        priceLevel={priceLevel}
        setPriceLevel={setPriceLevel}
        openNow={openNow}
        setOpenNow={setOpenNow}
        onApply={() => {
          setFilterModalVisible(false);
          fetchPlaces();
        }}
        onClear={resetFilters}
        onClose={() => {
          setFilterModalVisible(false);
        }}
      />

      {/* Place details modal*/}
      {selectedPlace && (
        <PlaceDetailsModal
          place={selectedPlace}
          visible={placeInfoModalVisible}
          onClose={() => setPlaceInfoModalVisible(false)}
          onAdd={() => {
            setPlaceInfoModalVisible(false);
            setDayTimeModalVisible(true);
            setSelectedDay(tripDays[0]);
          }}
          apiKey={GOOGLE_API_KEY}
          tripLocation={{ latitude: lat, longitude: lng }}
        />
      )}

      {/* Day & Time picker modal for adding activity */}
      <DayTimePickerModal
        visible={dayTimeModalVisible}
        tripDays={tripDays}
        selectedDay={selectedDay}
        selectedTime={selectedTime}
        setSelectedDay={setSelectedDay}
        setSelectedTime={setSelectedTime}
        onSave={(activity) => {
          handleAddActivity(selectedDay, {
            ...activity,
            title: selectedPlace?.name,
            address: selectedPlace?.vicinity || selectedPlace?.formatted_address || '',
            location: selectedPlace?.geometry?.location || null,
          });
          setDayTimeModalVisible(false);
          setSelectedPlace(null);
          setSelectedTime('');
        }}
        onCancel={() => setDayTimeModalVisible(false)}
      />
    </View>
  );
}
