import React, { useContext, useEffect, useRef } from 'react';
import { View, Text, FlatList, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import { useRouter, useLocalSearchParams, useNavigation } from 'expo-router';
import { CreateTripContext } from '../../context/CreateTripContext';
import moment from 'moment';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, Polyline } from 'react-native-maps';

// This screen displays the list of activities for a specific day in a trip
export default function DayDetails() {
  const { tripData, setTripData } = useContext(CreateTripContext);
  const router = useRouter();
  // read day param from navigation
  const params = useLocalSearchParams();
  const navigation = useNavigation();
  const mapRef = useRef(null);

  const day = params.day;
  const activities = tripData.activities?.[day] || [];

  // Get only activities with valid lat/lng and sort them by time
  const sortedLocations = activities
    ?.filter((a) => a?.location?.lat && a?.location?.lng)
    .sort((a, b) => (a.time || '').localeCompare(b.time || '')) || [];

  // Configure navigation header
  useEffect(() => {
    navigation.setOptions({
      headerShown: true,
      headerTransparent: true,
      headerTitle: ''
    });
  }, []);

  // Fit map to show all markers when locations exist
  useEffect(() => {
    if (mapRef.current && sortedLocations.length > 1) {
      const coordinates = sortedLocations.map(a => ({
        latitude: a.location.lat,
        longitude: a.location.lng,
      }));

      mapRef.current.fitToCoordinates(coordinates, {
        edgePadding: { top: 50, bottom: 50, left: 50, right: 50 },
        animated: true,
      });
    }
  }, [sortedLocations]);

   // If no day param, show fallback message
  if (!day) {
    return (
      <View style={styles.center}>
        <Text>No day selected</Text>
      </View>
    );
  }

  // Delete activity
  const handleDelete = (index) => {
    Alert.alert(
      'Delete Activity',
      'Are you sure you want to delete this activity?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            const updated = [...activities];
            // remove activity
            updated.splice(index, 1);
            setTripData(prev => ({
              ...prev,
              activities: {
                ...prev.activities,
                [day]: updated
              }
            }));
          }
        }
      ]
    );
  };

  // Render each activity
  const renderItem = ({ item, index }) => (
    <View style={styles.activityContainer}>
      <View style={{ flex: 1 }}>
        {/* Time */}
        {item.time ? <Text style={styles.time}>{item.time}</Text> : null}
        {/* Title */}
        <Text style={styles.title}>{item.title}</Text>
        {/* Address if available */}
        {item.address ? <Text style={styles.address}>{item.address}</Text> : null}
        {/* Description if available */}
        {item.description ? <Text style={styles.description}>{item.description}</Text> : null}
      </View>

      {/* Edit and Delete buttons */}
      <View style={styles.iconButtons}>
        <TouchableOpacity
          onPress={() =>
            router.push({
              pathname: 'activity/add-activity',
              params: { day, editIndex: index.toString() }
            })
          }
        >
          <Ionicons name="create-outline" size={24} color="black" style={styles.icon} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleDelete(index)}>
          <Ionicons name="trash-outline" size={24} color="#F44336" style={styles.icon} />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Day heading with formatted date */}
      <Text style={styles.heading}>
        Activities for Day {day} -{' '}
        {moment(tripData.startDate).add(Number(day) - 1, 'days').format('DD MMM YYYY')}
      </Text>

      {/* If no activities yet */}
      {activities.length === 0 && (
        <Text style={styles.noActivities}>No activities yet. Add some!</Text>
      )}

      {/* List of activities */}
      <FlatList
        data={activities}
        keyExtractor={(_, i) => i.toString()}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 20 }}
      />

      {/* Map with markers if locations exist */}
      {activities.some(a => a.location) && (
        <View style={{ height: 250, borderRadius: 10, overflow: 'hidden', marginBottom: 20 }}>
          <MapView
            ref={mapRef}
            style={{ flex: 1 }}
            initialRegion={{
              latitude: sortedLocations.length > 0 ? sortedLocations[0].location.lat : 37.9838,
              longitude: sortedLocations.length > 0 ? sortedLocations[0].location.lng : 23.7275,
              latitudeDelta: 0.05,
              longitudeDelta: 0.05,
            }}
          >
            {/* Place markers */}
            {sortedLocations.map((a, i) => (
              <Marker
                key={i}
                coordinate={{
                  latitude: a.location.lat,
                  longitude: a.location.lng,
                }}
                title={a.title}
                description={a.address}
              />
            ))}

            {/* Draw line if at least 2 locations */}
            {sortedLocations.length >= 2 && (
              <Polyline
                coordinates={sortedLocations.map((a) => ({
                  latitude: a.location.lat,
                  longitude: a.location.lng,
                }))}
                strokeColor="#4a90e2"
                strokeWidth={4}
              />
            )}
          </MapView>
        </View>
      )}

      {/* Add new activity button */}
      <TouchableOpacity
        onPress={() => router.push({ pathname: 'activity/add-activity', params: { day } })}
        style={styles.addBtn}
      >
        <Text style={styles.addBtnText}>+ Add Activity</Text>
      </TouchableOpacity>
    </View>
  );
}

// Styles for the screen
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  heading: { fontSize: 22, fontWeight: 'bold', marginBottom: 20, marginTop: 80 },
  noActivities: { fontSize: 16, fontStyle: 'italic', color: '#666', marginBottom: 20 },
  activityContainer: {
    flexDirection: 'row',
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#f8f9fa',
    marginBottom: 12,
    alignItems: 'center',
  },
  time: { fontWeight: '600', fontSize: 16, marginBottom: 4 },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 2 },
  description: { fontSize: 14, color: '#555', marginTop: 2 },
  iconButtons: { flexDirection: 'row', alignItems: 'center' },
  icon: { marginLeft: 15 },
  addBtn: {
    backgroundColor: '#000',
    padding: 15,
    borderRadius: 14,
    alignItems: 'center',
    marginTop: 'auto',
  },
  addBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  address: { fontSize: 14, color: '#999', marginTop: 2 },
});
