import { View, Text, Image, ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useLocalSearchParams, useNavigation } from 'expo-router';
import moment from 'moment';
import FlightInfo from '../../components/TripDetails/FlightInfo';
import HotelList from '../../components/TripDetails/HotelList';
import PlannedTrip from '../../components/TripDetails/PlannedTrip';

// Displays a saved trip with AI recommendations
export default function TripDetails() {
  const navigation = useNavigation();
  // Param passed from navigation
  const { trip } = useLocalSearchParams();
  const [tripDetails, setTripDetails] = useState(null);

  // Configure header and get trip
  useEffect(() => {
    navigation.setOptions({
      headerShown: true,
      headerTransparent: true,
      headerTitle: '',
    });

    try {
      const parsedTrip = JSON.parse(trip);
      setTripDetails(parsedTrip);
    } catch (err) {
      console.error('Failed to parse trip:', err);
    }
  }, []);

  if (!tripDetails) return null;
  const data = tripDetails.tripData;

  return (
    <ScrollView>
      {/* Destination image */}
      <Image
        source={{
          uri:
            'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=' +
            data?.locationInfo?.photoRef +
            '&key=' +
            process.env.EXPO_PUBLIC_GOOGLE_MAP_KEY,
        }}
        style={{
          width: '100%',
          height: 330,
        }}
      />

      {/* Trip Details */}
      <View
        style={{
          padding: 15,
          backgroundColor: '#fff',
          height: '100%',
          marginTop: -30,
          borderTopLeftRadius: 30,
          borderTopRightRadius: 30,
        }}
      >
        {/* Destination title */}
        <Text
          style={{
            fontFamily: 'outfit-bold',
            fontSize: 25,
          }}
        >
          {tripDetails?.tripPlan?.tripDetails?.location}
        </Text>

        {/* Date range */}
        <View
          style={{
            display: 'flex',
            flexDirection: 'row',
            gap: 5,
            marginTop: 5,
          }}
        >
          <Text
            style={{
              fontFamily: 'outfit',
              fontSize: 18,
              color: '#7d7d7d',
            }}
          >
            {moment(data?.startDate).format('DD MMM YYYY')}
          </Text>
          <Text
            style={{
              fontFamily: 'outfit',
              fontSize: 18,
              color: '#7d7d7d',
            }}
          >
            - {moment(data?.endDate).format('DD MMM YYYY')}
          </Text>
        </View>

        {/* Traveler type */}
        <Text
          style={{
            fontFamily: 'outfit',
            fontSize: 17,
            color: '#7d7d7d',
          }}
        >
          🚌 {data?.traveler?.title}
        </Text>

        {/* Flight information */}
        <FlightInfo flightData={tripDetails?.tripPlan?.flightDetails} />

        {/* Hotel options list */}
        <HotelList hotelList={tripDetails?.tripPlan?.hotelOptions} />

        {/* Daily plan */}
        <PlannedTrip details={tripDetails?.tripPlan?.dailyItinerary} />
      </View>
    </ScrollView>
  );
}
