import React, { useContext, useState, useEffect } from 'react';
import { SafeAreaView, View, Alert } from 'react-native';
import { useRouter, useLocalSearchParams, useNavigation } from 'expo-router';
import { AuthContext } from '../../context/AuthContext';
import { CreateTripContext } from '../../context/CreateTripContext';
import DayTimeline from '../../components/TripPlan/DayTimeline';
import TripCalendar from '../../components/TripPlan/TripCalendar';
import TripFooter from '../../components/TripPlan/TripFooter';
import api from '../../services/api';

// Displays and edits an existing trip's itinerary
export default function TripItinerary() {
  const router = useRouter();
  const navigation = useNavigation();

  const { user, token } = useContext(AuthContext);

  // Access and update trip data
  const { tripData, setTripData } = useContext(CreateTripContext);

  // Params passed from navigation
  const { trip } = useLocalSearchParams();

  const [ tripId, setTripId ] = useState(null);
  const [showCalendar, setShowCalendar] = useState(false);

  useEffect(() => {
    // Configure header
    navigation.setOptions({ headerShown: true, headerTransparent: true, headerTitle: '' });

    try {
      // Get the existing trip
      const parsed = JSON.parse(trip);
      setTripData(parsed.tripData);
      setTripId(parsed._id);
    } catch (err) {
      console.error('Failed to parse trip:', err);
    }
  }, [trip]);

  // Delete an activity from a day
  const handleDelete = (day, index) => {
    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete this activity?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            // Copy activities array for the day and remove the selected one
            const updated = [...(tripData.activities?.[day] || [])];
            updated.splice(index, 1);

            // Write back to context
            setTripData(prev => ({
              ...prev,
              activities: {
                ...prev.activities,
                [day]: updated
              }
            }));
          }
        }
      ]
    );
  };

  // Save the modified itinerary to backend
  const saveTrip = async () => {
    try {
      // Create a sorted copy of activities by time for each day
      const sortedActivities = {};
      for (const [day, acts] of Object.entries(tripData.activities || {})) {
        sortedActivities[day] = [...acts].sort((a, b) => a.time.localeCompare(b.time));
      }

      // Update context
      setTripData(prev => ({ ...prev, activities: sortedActivities }));

      // Add the activities in the selected trip
      const res = await api.post('/trips/update', {
        userEmail: user.email,
        tripId: tripId,
        activities: sortedActivities,
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });

      if (res.data.success) {
        Alert.alert('Save Trip', 'Trip saved successfully!');
        router.push('home/mytrip');
      } else {
        throw new Error('Failed to save trip');
      }
    } catch (err) {
      Alert.alert('Error', err.message);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <View style={{ flex: 1, paddingHorizontal: 25 }}>
        {/* Switch between Calendar and Timeline */}
        {showCalendar ? (
          <TripCalendar tripData={tripData} />
        ) : (
          <DayTimeline tripData={tripData} onDelete={handleDelete} />
        )}
      </View>

      {/* Footer */}
      <TripFooter
        showCalendar={showCalendar}
        onToggle={() => setShowCalendar(prev => !prev)}
        onSave={saveTrip}
        location={tripData.locationInfo?.cordinates}
      />
    </SafeAreaView>
  );
}
