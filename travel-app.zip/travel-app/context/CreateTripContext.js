import React, { createContext, useState } from 'react';

// Create a context that can be shared across components
// This will allow components to access and update trip  data
export const CreateTripContext = createContext();

export const CreateTripProvider = ({ children }) => {
  const [tripData, setTripData] = useState(null);

  return (
    <CreateTripContext.Provider value={{ tripData, setTripData }}>
      {children}
    </CreateTripContext.Provider>
  );
};
