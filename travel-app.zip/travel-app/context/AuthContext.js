import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';
import api from '../services/api';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); 
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Function to load user on app start
    const loadUser = async () => {
      try {
        // Get token from local storage
        const storedToken = await AsyncStorage.getItem('token');

        if (storedToken) {
          setToken(storedToken);

          // Call backend to verify token and fetch user
          const res = await api.get('/auth/me', {
            headers: { Authorization: `Bearer ${storedToken}` },
          });

          if (res.status === 200) {
            console.log('Valid token and user data');
            setUser(res.data);
          } else {
            console.log('Invalid token or missing user data:', res.status, res.data);
            throw new Error('Invalid token');
          }
        } else {
          // No token found
          console.log('No token found');
          setUser(null);
          setToken(null);
        }
      } catch (e) {
        console.log('Error loading user:', e.message);
        await AsyncStorage.removeItem('token');
        setUser(null);
        setToken(null);
      } finally {
        setLoading(false);
      }
    };
    
    loadUser();
  }, []);

  // Google login
  const googleLogin = async (googleAccessToken) => {
    try {
      const res = await api.post('/auth/google-login', { token: googleAccessToken });

      const token = res.data.token;
      const user = res.data.user;

      await AsyncStorage.setItem('token', token);
      setToken(token);
      setUser(user);

      return { success: true };
    } catch (error) {
      console.log('Google login error:', error);
      return {
        success: false,
        message: error.response?.data?.msg || 'Google login failed',
      };
    }
  };

  // Apple login
  const appleLogin = async (identityToken) => {
    try {
      const res = await api.post('/auth/apple-login', { id_token: identityToken });

      const token = res.data.token;
      const user = res.data.user;

      await AsyncStorage.setItem('token', token);
      setToken(token);
      setUser(user);

      return { success: true, user: user };
    } catch (error) {
      console.log('Apple login error:', error);
      return {
        success: false,
        message: error.response?.data?.msg || 'Apple login failed',
      };
    }
  };

  // Login user with email & password
  const login = async (email, password) => {
    try {
      // Backend validates credentials
      const res = await api.post('/auth/login', { email, password });

      // Extract token and user from response
      const token = res.data.token;
      const user = res.data.user || res.data;

      // Save token locally so user stays logged in after app restarts
      await AsyncStorage.setItem('token', token);
      setToken(token);
      setUser(user);

      return { success: true, user: user };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.msg || 'Login failed',
      };
    }
  };

  // Logout user
  const logout = async (onLogoutComplete) => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          await AsyncStorage.removeItem('token');
          setToken(null);
          setUser(null);
          if (onLogoutComplete) {
            onLogoutComplete();
          }
        },
      },
    ]);
  };

  // Register user
  const register = async (email, password, name) => {
    try {
      // Call backend to create new user
      const res = await api.post('/auth/register', { email, password, name });

      // Extract token and user from response
      const token = res.data.token;
      const user = res.data.user || res.data;

      // Save token locally
      await AsyncStorage.setItem('token', token);
      setToken(token);
      setUser(user);
      
      return { success: true };
    } catch (err) {
      return { success: false, message: err.response?.data?.msg || 'Registration failed' };
    }
  };

  // Update user profile
  const updateUser = async (name, email) => {
    try {
      const res = await api.put('/auth/update-profile', { name, email }, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.data.success) {
        setUser(res.data.user);
        return { success: true };
      }

      return { success: false, message: res.data.message };
    } catch (err) {
      return { success: false, message: err.response?.data?.msg || 'Failed to update profile.' };
    }
  };


  // Delete account 
  const deleteAccount = async () => {
    try {
      // Backend deletes trips & tripPlans
      const res = await api.delete('/auth/delete', {
        headers: { Authorization: `Bearer ${token}` },
      });

      // On success, clear token & user locally
      await AsyncStorage.removeItem('token');
      setToken(null);
      setUser(null);

      return { success: true, message: res.data.message };
    } catch (error) {
      console.error('Delete account failed:', error);
      return false;
    }
  };

  // Reset password 
  const resetPassword = async (email, newPassword) => {
    try {
      const res = await api.post('/auth/reset-password', { email, newPassword });

      if (res.data.success) {
        return { success: true, message: res.data.msg || 'Password updated' };
      }

      return { success: false, message: res.data.msg || 'Failed to update password' };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.msg || 'Server error',
      };
    }
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, googleLogin,
      appleLogin, login, logout, register, updateUser, deleteAccount, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
};
