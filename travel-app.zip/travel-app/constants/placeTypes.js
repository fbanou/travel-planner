// Place type options
export const placeTypes = [
    { label: 'Restaurants 🍽️', value: 'restaurant' },
    { label: 'Cafe ☕', value: 'cafe' },
    { label: 'Museums 🖼️', value: 'museum' },
    { label: 'Parks 🌳', value: 'park' },
    { label: 'Sights 🏛', value: 'tourist_attraction' },
    { label: 'Shops 🛍', value: 'shopping_mall' },
    { label: 'Hotels 🛌', value: 'lodging' },
];