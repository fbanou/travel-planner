const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define TripPlan schema
const tripPlanSchema = new Schema({
  tripDetails: {
    location: String,
    duration: String,
    budget: String,
    travelers: String,
    theme: String,
  },
  flightDetails: {
    type: Object
  },
  hotelOptions: [{
    type: Object
  }],
  dailyItinerary: [{
    day: String,
    theme: String,      
    schedule: [{
      type: Object
    }]
  }],
  tripId: { // This will link to the Trip model
    type: Schema.Types.ObjectId,
    ref: 'Trip',
  }
}, {
  timestamps: true
});

// Define Activities schema
const ActivitySchema = new mongoose.Schema({
  time: String,
  title: String,
  description: String
})

// Define Trips schema
const tripSchema = new Schema({
  userEmail: {
    type: String,
    required: true
  },
  tripPlan: {
    type: Schema.Types.ObjectId,
    ref: 'TripPlan',  // Linking to TripPlan collection
  },
  tripData: {
    type: Object,
    required: true
  },
  isFavorite: {
    type: Boolean,
    default: false,
  },
  members: { type: [String], default: [] },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create the Trip model
const TripPlan = mongoose.model('TripPlan', tripPlanSchema);
const Trip = mongoose.model('Trip', tripSchema);

module.exports = {
  Trip,
  TripPlan
};