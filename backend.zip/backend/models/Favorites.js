const mongoose = require('mongoose');

// Define Favorites schema
const favoriteSchema = new mongoose.Schema({
  userId: String,
  placeId: String,
  name: String,
  address: String,
  rating: Number,
  photoReference: String,
  location: {
    lat: Number,
    lng: Number,
  },
});

module.exports = mongoose.model('Favorite', favoriteSchema);
