const express = require('express');
const Favorite = require('../models/Favorites');
const router = express.Router();

// Get all favorites for user
router.get('/:userId', async (req, res) => {
  const { userId } = req.params;
  const favorites = await Favorite.find({ userId });
  res.json(favorites);
});

// Add favorite
router.post('/', async (req, res) => {
  const fav = new Favorite(req.body);
  await fav.save();
  res.json(fav);
});

// Remove favorite
router.delete('/:userId/:placeId', async (req, res) => {
  const { userId, placeId } = req.params;
  await Favorite.deleteOne({ userId, placeId });
  res.json({ success: true });
});

module.exports = router;
