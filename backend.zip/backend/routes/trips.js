const express = require('express');
const router = express.Router();
const { Trip, TripPlan } = require('../models/Trip');
const User = require('../models/User');

// Save a trip with AI-generated plan
router.post('/', async (req, res) => {
  try {
    const { userEmail, tripPlan, tripData } = req.body;

    // Validate input
    if (!userEmail || !tripData || !tripPlan) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    // Transform dailyItinerary object into array
    const itineraryArray = Object.entries(tripPlan.dailyItinerary).map(([key, value]) => {
      return {
        day: key,
        date: value?.date,
        theme: value?.theme,
        schedule: value?.schedule
      };
    });

    // Save TripPlan
    const newTripPlan = new TripPlan({
      tripDetails: tripPlan.tripDetails,
      flightDetails: tripPlan.flightDetails,
      hotelOptions: tripPlan.hotelOptions,
      dailyItinerary: itineraryArray
    });
    await newTripPlan.save();

    // Save Trip referencing TripPlan
    const newTrip = new Trip({
      userEmail: userEmail,
      tripPlan: newTripPlan._id,
      tripData: tripData,
      createdAt: new Date()
    });
    await newTrip.save();

    res.status(201).json({ message: 'Trip saved successfully' });
  } catch (error) {
    console.error('Trip save error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all trips for a user
router.get('/:email', async (req, res) => {
  try {
    // Fetch trips and include TripPlan details
    const trips = await Trip.find({ userEmail: req.params.email })
      .populate('tripPlan');

    console.log('Found trips');
    res.status(200).json(trips);
  } catch (err) {
    console.error('Error in tripdata: ' + err);
    res.status(500).json({ error: 'Error fetching trips' });
  }
});

// Get trips where user is a member
router.get('/member/:email', async (req, res) => {
  try {
    const email = req.params.email.trim().toLowerCase();

    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: 'User not found' });

    const trips = await Trip.find({ members: email }).populate('tripPlan').sort({ 'tripData.startDate': 1 });
    
    console.log('Found trips for member');
    res.status(200).json(trips);
  } catch (err) {
    console.error('Error in tripdata: ' + err);
    res.status(500).json({ error: 'Error fetching trips' });
  }
});

// Create new trip
router.post('/create', async (req, res) => {
  try {
    const { userEmail, tripData } = req.body;

    const trip = new Trip({
      userEmail: userEmail,
      tripData: tripData,
      createdAt: new Date()
    });

    await trip.save()
    console.log('New trip: ', trip)
    res.status(201).json({ success: true, tripId: trip._id })
  } catch (err) {
    res.status(500).json({ error: 'Failed to create trip' })
  }
})

// Update trip activities
router.post('/update', async (req, res) => {
  try {
    const { userEmail, tripId, activities } = req.body;

    if (!userEmail || !tripId || !activities) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Find and update trip
    const trip = await Trip.findOneAndUpdate(
      { _id: tripId },
      { $set: { 'tripData.activities': activities } },
      { new: true }
    );

    if (!trip) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    console.log('Updated trip: ', trip);
    res.status(200).json({ success: true, tripId: trip._id, updatedTrip: trip });

  } catch (err) {
    console.error('Error updating trip:', err);
    res.status(500).json({ error: 'Failed to update trip' });
  }
});

// Delete a trip
router.delete('/:tripId', async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.tripId);

    if (!trip) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    // Delete associated TripPlan if it exists
    if (trip?.tripPlan) {
      await TripPlan.findByIdAndDelete(trip.tripPlan);
    }

    // Delete Trip 
    await Trip.findByIdAndDelete(req.params.tripId);

    res.json({ message: 'Trip and associated TripPlan deleted successfully' });
  } catch (err) {
    console.error('Delete error:', err);
    res.status(500).json({ error: 'Failed to delete trip and trip plan' });
  }
});

// Toggle trip as favorite
router.patch('/favorite/:tripId', async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.tripId);

    // Ensure boolean toggle works even if undefined
    if (typeof trip.isFavorite !== 'boolean') {
      trip.isFavorite = false;
    }

    trip.isFavorite = !trip.isFavorite;
    console.log('Favorite trip: ', trip.isFavorite);

    await trip.save();
    res.json({ message: 'Favorite toggled', isFavorite: trip.isFavorite });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to toggle favorite' });
  }
});

// Get favorite trips for a user
router.get('/favorites/:email', async (req, res) => {
  try {
    const favoriteTrips = await Trip.find({
      isFavorite: true,
      userEmail: req.params.email,
    }).populate('tripPlan');

    console.log('Favorite trips');
    res.json(favoriteTrips);
  } catch (err) {
    console.error('Error fetching user favorites:', err);
    res.status(500).json({ error: 'Failed to fetch user favorite trips' });
  }
});

// Add user as member to a trip
router.patch('/addUser', async (req, res) => {
  try {
    const { tripId, email } = req.body;

    if (!tripId || !email) return res.status(400).json({ message: 'tripId and email are required' });

    // Ensure user exists
    const user = await User.findOne({ email: email.trim().toLowerCase() });
    if (!user) return res.status(404).json({ success: false, msg: 'User not found' });

    const clean = email.trim().toLowerCase();
    const trip = await Trip.updateOne(
      { _id: tripId },
      { $addToSet: { members: clean } } // prevents duplicates
    );

    if (trip.matchedCount === 0) return res.status(404).json({ message: 'Trip not found' });
    if (trip.modifiedCount === 0) return res.status(409).json({ message: 'User already in trip' });

    return res.status(200).json({
      success: true
    });
  } catch (err) {
    console.error('Error adding user to trip:', err);
    return res.status(500).json({ message: 'Failed to add user to trip' });
  }
});

module.exports = router;
