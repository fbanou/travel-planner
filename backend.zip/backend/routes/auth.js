const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { Trip, TripPlan } = require('../models/Trip');
const authMiddleware = require('../middleware/authMiddleware');
const { OAuth2Client } = require('google-auth-library');
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);
const appleSignin = require('apple-signin-auth');

// Helper to create JWT token with expiration
const createToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' }); // expires in 7 days
};

// Register route
router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;

  if (!email || !password || !name) {
    return res.status(400).json({ msg: 'Please provide name, email and password' });
  }

  try {
    let user = await User.findOne({ email });
    if (user) return res.status(400).json({ msg: 'User already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);

    user = new User({
      email,
      password: hashedPassword,
      name,
    });

    await user.save();

    const token = createToken(user._id);

    res.status(201).json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
      },
    });

    console.log('New user: ', user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// Login route
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ msg: 'Please provide email and password' });

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: 'Invalid credentials' });

    const token = createToken(user._id);

    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
      },
    });

    console.log('User: ', user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

router.delete('/delete', authMiddleware, async (req, res) => {
  try {
    const userEmail = req.user.email;

    // Delete the user
    const user = await User.findOneAndDelete({ email: userEmail });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find all related trips
    const trips = await Trip.find({ userEmail });

    for (const trip of trips) {
      // Delete associated trip plan if exists
      if (trip.tripPlan) {
        await TripPlan.findByIdAndDelete(trip.tripPlan);
      }
      // Delete the trip itself
      await Trip.findByIdAndDelete(trip._id);
    }

    console.log('deleted user: ', userEmail)

    res.status(200).json({ message: 'User, trips, and trip plans deleted' });
  } catch (err) {
    console.error('Delete user cascade error:', err);
    res.status(500).json({ error: 'Failed to delete user and related data' });
  }
});

// Google Login Route
router.post('/google-login', async (req, res) => {
  const { idToken } = req.body;

  try {
    const ticket = await googleClient.verifyIdToken({
      idToken,
      audience: GOOGLE_CLIENT_ID,
    });

    const payload = ticket.getPayload();
    const { email, name } = payload;

    let user = await User.findOne({ email });

    if (!user) {
      user = new User({
        email,
        name,
        password: 'google_oauth', 
      });
      await user.save();
    }

    const token = createToken(user._id);

    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
      },
    });

    console.log('Google login success for:', user.email);
  } catch (error) {
    console.error('Google login error:', error);
    res.status(400).json({ msg: 'Google login failed' });
  }
});

// Apple Login Route
router.post('/apple-login', async (req, res) => {
  const { id_token } = req.body;
  
  try {
    const appleResponse = await appleSignin.verifyIdToken(id_token, {
      audience: process.env.APPLE_SERVICE_ID,
    });

    console.log('Apple user payload:', appleResponse);

    const { email, sub: appleId } = appleResponse;

    let user = await User.findOne({ email });

    if (!user) {
      const nameFromEmail = email?.split('@')[0] || 'Apple User';

      user = new User({
        email,
        name: nameFromEmail,
        password: 'apple_oauth',
      });

      await user.save();
    }

    const token = createToken(user._id);

    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
      },
    });

    console.log('Apple login success for:', user.email);
  } catch (error) {
    console.error('Apple login error:', error);
    res.status(400).json({ msg: 'Apple login failed' });
  }
});

router.get('/me', authMiddleware, (req, res) => {
  // req.user is set in middleware
  console.log('Found user: ', req.user);
  res.json(req.user);
});

router.put('/update-profile', authMiddleware, async (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({ success: false, message: 'Όλα τα πεδία είναι υποχρεωτικά.' });
  }

  try {
    // Βρες τον τρέχοντα χρήστη
    const currentUser = await User.findById(req.user.id);
    const oldEmail = currentUser.email;

    // Ενημέρωσε τον χρήστη
    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      { name, email },
      { new: true }
    );

    // Ενημέρωσε τα trips που είχαν το παλιό email
    await Trip.updateMany({ userEmail: oldEmail }, { userEmail: email });

    console.log('Update user: ', updatedUser);

    res.json({ success: true, user: updatedUser });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Κάτι πήγε στραβά.' });
  }
});

// Reset password 
router.post('/reset-password', async (req, res) => {
  const { email, newPassword } = req.body;

  if (!email || !newPassword) {
    return res.status(400).json({ success: false, msg: 'Email and new password required' });
  }

  try {
    const user = await User.findOne({ email });

    if (!user) return res.status(404).json({ success: false, msg: 'User not found' });

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    console.log(`Password reset for user: ${email}`);
    res.json({ success: true, msg: 'Password updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, msg: 'Server error' });
  }
});


module.exports = router;
