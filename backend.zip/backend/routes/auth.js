const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { Trip, TripPlan } = require('../models/Trip');
const Favorite = require('../models/Favorites');
const authMiddleware = require('../middleware/authMiddleware');
const { OAuth2Client } = require('google-auth-library');
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);
const appleSignin = require('apple-signin-auth');

// Helper to create JWT token with expiration
const createToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' }); // expires in 7 days
};

// Register new user
router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;

  if (!email || !password || !name) {
    return res.status(400).json({ msg: 'Please provide name, email and password' });
  }

  try {
    // Check if user already exists
    let user = await User.findOne({ email });
    if (user) return res.status(400).json({ msg: 'User already exists' });

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user
    user = new User({
      email,
      password: hashedPassword,
      name,
    });
    await user.save();

    // Create JWT token
    const token = createToken(user._id);

    res.status(201).json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
      },
    });

    console.log('New user: ', user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// Login user
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ msg: 'Please provide email and password' });

  try {
    // Find user
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: 'Invalid credentials' });

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: 'Invalid credentials' });

    // Create token
    const token = createToken(user._id);

    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
      },
    });

    console.log('User: ', user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// Delete user
router.delete('/delete', authMiddleware, async (req, res) => {
  try {
    const userEmail = req.user.email;

    // Delete the user
    const user = await User.findOneAndDelete({ email: userEmail });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Delete all trips and related trip plans
    const trips = await Trip.find({ userEmail });

    for (const trip of trips) {
      if (trip.tripPlan) {
        await TripPlan.findByIdAndDelete(trip.tripPlan);
      }

      await Trip.findByIdAndDelete(trip._id);
    }

    // Delete all favorites
    const favorites = await Favorite.find({ userId: userEmail });

    for (const favorite of favorites) {
      await Favorite.findByIdAndDelete(favorite._id);
    }

    console.log('deleted user: ', userEmail)

    res.status(200).json({ message: 'User, trips, and trip plans deleted' });
  } catch (err) {
    console.error('Delete user cascade error:', err);
    res.status(500).json({ error: 'Failed to delete user and related data' });
  }
});

// Google Login
router.post('/google-login', async (req, res) => {
  const { idToken } = req.body;

  try {
    const ticket = await googleClient.verifyIdToken({
      idToken,
      audience: GOOGLE_CLIENT_ID,
    });

    const payload = ticket.getPayload();
    const { email, name } = payload;

    let user = await User.findOne({ email });

    if (!user) {
      user = new User({
        email,
        name,
        password: 'google_oauth', 
      });
      await user.save();
    }

    const token = createToken(user._id);

    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
      },
    });

    console.log('Google login success for:', user.email);
  } catch (error) {
    console.error('Google login error:', error);
    res.status(400).json({ msg: 'Google login failed' });
  }
});

// Apple Login
router.post('/apple-login', async (req, res) => {
  const { id_token } = req.body;
  
  try {
    const appleResponse = await appleSignin.verifyIdToken(id_token, {
      audience: process.env.APPLE_SERVICE_ID,
    });

    console.log('Apple user payload:', appleResponse);

    const { email, sub: appleId } = appleResponse;

    let user = await User.findOne({ email });

    if (!user) {
      const nameFromEmail = email?.split('@')[0] || 'Apple User';

      user = new User({
        email,
        name: nameFromEmail,
        password: 'apple_oauth',
      });

      await user.save();
    }

    const token = createToken(user._id);

    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
      },
    });

    console.log('Apple login success for:', user.email);
  } catch (error) {
    console.error('Apple login error:', error);
    res.status(400).json({ msg: 'Apple login failed' });
  }
});

// Get current user
router.get('/me', authMiddleware, (req, res) => {
  console.log('Found user: ', req.user);
  res.json(req.user);
});

// Update user profile
router.put('/update-profile', authMiddleware, async (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({ success: false, message: 'All fields are required' });
  }

  try {
    // Find current user
    const currentUser = await User.findById(req.user.id);
    const oldEmail = currentUser.email;

    // Update user
    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      { name, email },
      { new: true }
    );

    // Update trips linked to old email
    await Trip.updateMany({ userEmail: oldEmail }, { userEmail: email });

    // Update favorites linked to old email
    await Favorite.updateMany({ userId: oldEmail }, { userId: email });

    console.log('Update user: ', updatedUser);

    res.json({ success: true, user: updatedUser });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Error in update user' });
  }
});

// Reset password 
router.post('/reset-password', async (req, res) => {
  const { email, newPassword } = req.body;

  if (!email || !newPassword) {
    return res.status(400).json({ success: false, msg: 'Email and new password required' });
  }

  try {
    const user = await User.findOne({ email });

    if (!user) return res.status(404).json({ success: false, msg: 'User not found' });

    // Hash new password and save
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    console.log(`Password reset for user: ${email}`);
    res.json({ success: true, msg: 'Password updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, msg: 'Server error' });
  }
});


module.exports = router;
