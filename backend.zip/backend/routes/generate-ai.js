const express = require('express');
const router = express.Router();

const { GoogleGenerativeAI } = require("@google/generative-ai");

const apiKey = process.env.EXPO_PUBLIC_GOOGLE_GEMINI_KEY;
const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({
    model: "gemini-2.0-flash",
});

const generationConfig = {
    temperature: 1,
    topP: 0.95,
    topK: 40,
    maxOutputTokens: 8192,
    responseMimeType: 'application/json',
};

const chatSession = model.startChat({
    generationConfig,
    history: [
        {
            role: 'user',
            parts: [
                { text: 'Generate Travel Plan for Location : Thessaloniki, Greece, for 3 Days and 2 Nights for A Couple with a Moderate budget with a Flight details, Flight Price with Booking url, Hotels options list with HotelName, Hotel address, Price, hotel image url, Geo Coordinates, rating, descriptions and Places to visit nearby with placeName, Place Details, Place Image Url, Geo Coordinates, ticket Pricing, Time to travel each of the location for 3 days and 2 nights with each day plan with the best time to visit in JSON format\n' },
            ],
        },
        {
            role: 'model',
            parts: [
                {
                    text: JSON.stringify(
                        {
                            "tripDetails": {
                                "location": "Thessaloniki, Greece",
                                "duration": "3 Days, 2 Nights",
                                "budget": "Moderate",
                                "travelers": "Couple",
                                "theme": "Historical Exploration & Cultural Immersion"
                            },
                            "flightDetails": {
                                "departureCity": "Volos (VOL), Greece",
                                "arrivalCity": "Thessaloniki (SKG), Greece",
                                "departureTime": "08:50",
                                "arrivalTime": "15:40",
                                "airline": "Aegean Airlines",
                                "flightNumber": "A3 7091",
                                "flightPrice": "141.51 - 187.12",
                                "currency": "EUR",
                                "bookingUrl": "https://www.expedia.com/lp/flights/vol/skg/volos-to-thessaloniki",
                                "notes": "Round trip prices per person. Verify times and prices before booking."
                            },
                            "hotelOptions": [
                                {
                                    "hotelName": "Urban Donkey Hotel",
                                    "hotelAddress": "Arkadioupoleos 11, Thessaloniki",
                                    "pricePerNight": "70 - 120",
                                    "currency": "EUR",
                                    "hotelImageUrl": "https://urbandonkey.gr/wp-content/uploads/2021/03/Urban-Donkey-Hotel-Thessaloniki-Exterior-Night.jpg",
                                    "geoCoordinates": {
                                        "latitude": 40.6441,
                                        "longitude": 22.9431
                                    },
                                    "rating": 4.5,
                                    "description": "Stylish and modern central hotel, ideal for couples.",
                                    "amenities": ["Free Wifi", "Air Conditioning", "Pet Friendly"]
                                },
                                {
                                    "hotelName": "COLORS Urban Hotel",
                                    "hotelAddress": "Tsimiski 23, Thessaloniki",
                                    "pricePerNight": "80 - 130",
                                    "currency": "EUR",
                                    "hotelImageUrl": "https://www.colorshotel.gr/wp-content/uploads/2022/03/colors-urban-hotel-thessaloniki-exterior.jpg",
                                    "geoCoordinates": {
                                        "latitude": 40.6358,
                                        "longitude": 22.9427
                                    },
                                    "rating": 4.5,
                                    "description": "Modern hotel in the heart of Thessaloniki, perfect base for exploration.",
                                    "amenities": ["Free Wifi", "Bar", "Massage Services"]
                                },
                                {
                                    "hotelName": "Mandrino Hotel",
                                    "hotelAddress": "Egnatia 2, Thessaloniki",
                                    "pricePerNight": "60 - 100",
                                    "currency": "EUR",
                                    "hotelImageUrl": "https://www.booking.com/hotel/gr/mandrino.en-gb.html",
                                    "geoCoordinates": {
                                        "latitude": 40.6369,
                                        "longitude": 22.9405
                                    },
                                    "rating": 4.0,
                                    "description": "Budget-friendly, centrally located on Egnatia Street.",
                                    "amenities": ["Free Wifi", "24h Reception"]
                                }
                            ],
                            "dailyItinerary": {
                                "day1": {
                                    "theme": "Arrival, Roman & Byzantine History, and Evening Stroll",
                                    "schedule": [
                                        {
                                            "time": "12:00",
                                            "activity": "Check-in at Hotel",
                                            "details": "Settle into your chosen accommodation and relax.",
                                            "duration": "1 hour"
                                        },
                                        {
                                            "time": "13:00",
                                            "activity": "Arch of Galerius & Rotunda",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Arch_of_Galerius%2C_Thessaloniki_%281%29.jpg/1200px-Arch_of_Galerius%2C_Thessaloniki_%281%29.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6334,
                                                "longitude": 22.9511
                                            },
                                            "ticketPricing": "Free / ~2€ for Rotunda",
                                            "duration": "1.5 - 2 hours"
                                        },
                                        {
                                            "time": "15:00",
                                            "activity": "Church of Hagios Demetrios",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/b/b3/Church_of_Saint_Demetrius_%28Thessaloniki%29_-_HDR.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6377,
                                                "longitude": 22.9467
                                            },
                                            "ticketPricing": "Free",
                                            "duration": "1.5 hours"
                                        },
                                        {
                                            "time": "17:00",
                                            "activity": "Aristotelous Square & Waterfront Promenade",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Aristotelous_Square_Thessaloniki_Greece.jpg/1200px-Aristotelous_Square_Thessaloniki_Greece.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6327,
                                                "longitude": 22.9405
                                            },
                                            "ticketPricing": "Free",
                                            "duration": "1.5 - 2 hours"
                                        },
                                        {
                                            "time": "19:30",
                                            "activity": "Dinner in Ladadika Quarter",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/Ladadika_Thessaloniki_by_Night_2016.jpg/1200px-Ladadika_Thessaloniki_by_Night_2016.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6332,
                                                "longitude": 22.9366
                                            },
                                            "ticketPricing": "Moderate",
                                            "duration": "2 hours"
                                        }
                                    ]
                                },
                                "day2": {
                                    "theme": "Cultural Immersion & Old Town Charm",
                                    "schedule": [
                                        {
                                            "time": "09:00",
                                            "activity": "Archaeological Museum of Thessaloniki",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Archaeological_Museum_of_Thessaloniki_2017.jpg/1200px-Archaeological_Museum_of_Thessaloniki_2017.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6277,
                                                "longitude": 22.9540
                                            },
                                            "ticketPricing": "8€",
                                            "duration": "2 - 3 hours"
                                        },
                                        {
                                            "time": "11:30",
                                            "activity": "White Tower of Thessaloniki",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/White_Tower_of_Thessaloniki_-_Exterior.jpg/1200px-White_Tower_of_Thessaloniki_-_Exterior.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6267,
                                                "longitude": 22.9484
                                            },
                                            "ticketPricing": "4€",
                                            "duration": "1.5 hours"
                                        },
                                        {
                                            "time": "14:00",
                                            "activity": "Ano Poli (Upper Town) & City Walls",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Ano_Poli_Thessaloniki_Greece.jpg/1200px-Ano_Poli_Thessaloniki_Greece.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6430,
                                                "longitude": 22.9515
                                            },
                                            "ticketPricing": "Free",
                                            "duration": "2 - 3 hours"
                                        },
                                        {
                                            "time": "16:30",
                                            "activity": "Vlatadon Monastery",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Vlatadon_Monastery%2C_Thessaloniki.jpg/1200px-Vlatadon_Monastery%2C_Thessaloniki.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6455,
                                                "longitude": 22.9566
                                            },
                                            "ticketPricing": "Free (donations welcome)",
                                            "duration": "1 hour"
                                        },
                                        {
                                            "time": "19:00",
                                            "activity": "Dinner with City Views (e.g., OTE Tower)",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/OTE_Tower_2018.jpg/1200px-OTE_Tower_2018.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6277,
                                                "longitude": 22.9461
                                            },
                                            "ticketPricing": "Varies by restaurant",
                                            "duration": "2 hours"
                                        }
                                    ]
                                },
                                "day3": {
                                    "theme": "Markets, Modern Art & Departure",
                                    "schedule": [
                                        {
                                            "time": "09:00",
                                            "activity": "Kapani & Modiano Markets",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Kapani_Market%2C_Thessaloniki.jpg/1200px-Kapani_Market%2C_Thessaloniki.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6366,
                                                "longitude": 22.9392
                                            },
                                            "ticketPricing": "Free",
                                            "duration": "2 hours"
                                        },
                                        {
                                            "time": "11:30",
                                            "activity": "Museum of Byzantine Culture",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Museum_of_Byzantine_Culture%2C_Thessaloniki_%281%29.jpg/1200px-Museum_of_Byzantine_Culture%2C_Thessaloniki_%281%29.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.6288,
                                                "longitude": 22.9580
                                            },
                                            "ticketPricing": "8€",
                                            "duration": "2 hours"
                                        },
                                        {
                                            "time": "13:30",
                                            "activity": "MOMus – Museum of Contemporary Art",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Thessaloniki_Concert_Hall_-_June_2018.jpg/1200px-Thessaloniki_Concert_Hall_-_June_2018.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.5960,
                                                "longitude": 22.9691
                                            },
                                            "ticketPricing": "5€-10€",
                                            "duration": "1.5 - 2 hours"
                                        },
                                        {
                                            "time": "15:30",
                                            "activity": "Farewell Coffee or Snack",
                                            "details": "Enjoy a last treat in the city center.",
                                            "duration": "1 hour"
                                        },
                                        {
                                            "time": "17:00",
                                            "activity": "Departure to Thessaloniki Airport (SKG)",
                                            "placeImageUrl": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Thessaloniki_Airport_Makedonia.jpg/1200px-Thessaloniki_Airport_Makedonia.jpg",
                                            "geoCoordinates": {
                                                "latitude": 40.5197,
                                                "longitude": 22.9709
                                            },
                                            "ticketPricing": "N/A",
                                            "duration": "1 hour"
                                        }
                                    ]
                                }
                            }
                        }, null, 2)
                }
            ],
        },
    ],
});

router.post('/plan-trip', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
    }

    try {
        const result = await chatSession.sendMessage(prompt);
        const text = result.response.text();

        res.json({ result: text });
    } catch (error) {
        console.error('Error generating travel plan:', error);
        res.status(500).json({ error: 'Something went wrong', details: error.message });
    }
});

module.exports = router;